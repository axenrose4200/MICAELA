<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DateDraftText</name>
   <tag></tag>
   <elementGuidId>45002af1-124e-4072-872b-7248bea6af09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//p[contains(text(), &quot;Last Saved&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//p[contains(text(), &quot;Last Saved&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
