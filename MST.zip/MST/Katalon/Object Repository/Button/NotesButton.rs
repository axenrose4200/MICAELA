<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>NotesButton</name>
   <tag></tag>
   <elementGuidId>a719ebbc-f85c-4224-b828-f19ac64f8de7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//strong[text() = &quot;Click here&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//strong[text() = &quot;Click here&quot;]</value>
   </webElementProperties>
</WebElementEntity>
