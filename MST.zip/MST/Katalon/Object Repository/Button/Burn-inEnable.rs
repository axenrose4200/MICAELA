<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Burn-inEnable</name>
   <tag></tag>
   <elementGuidId>ad05c989-c635-4094-882e-859533a09581</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Burn-in: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Burn-in: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
   </webElementProperties>
</WebElementEntity>
