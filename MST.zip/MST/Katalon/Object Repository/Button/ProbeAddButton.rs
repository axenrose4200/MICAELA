<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeAddButton</name>
   <tag></tag>
   <elementGuidId>432a5429-a6fa-4337-a1c7-c4eec5e34a3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[text()=&quot; Probe &quot;]//parent::span//parent::mat-expansion-panel-header//following-sibling::div//mat-action-row//button//span//mat-icon[text()=&quot;add&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[text()=&quot; Probe &quot;]//parent::span//parent::mat-expansion-panel-header//following-sibling::div//mat-action-row//button//span//mat-icon[text()=&quot;add&quot;]</value>
   </webElementProperties>
</WebElementEntity>
