<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dontSave.SaveAsNew</name>
   <tag></tag>
   <elementGuidId>a35d7b4f-c833-4162-8732-657edc4613b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class=&quot;mat-raised-button mat-accent&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class=&quot;mat-raised-button mat-accent&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
