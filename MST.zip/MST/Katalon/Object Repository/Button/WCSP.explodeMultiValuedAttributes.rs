<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.explodeMultiValuedAttributes</name>
   <tag></tag>
   <elementGuidId>60df19da-7184-46ed-9eb2-2fa292c7be82</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
