<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ItemsPackage</name>
   <tag></tag>
   <elementGuidId>ef752f8d-9332-4d38-b9f0-de3b92d72bcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
