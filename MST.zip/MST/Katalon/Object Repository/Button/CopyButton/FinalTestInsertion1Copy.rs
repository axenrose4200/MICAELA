<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestInsertion1Copy</name>
   <tag></tag>
   <elementGuidId>bb1b3425-571d-4ae1-bb39-ecbd17ee3323</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[text()=&quot; Final Test &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[text()=&quot; Final Test &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;]</value>
   </webElementProperties>
</WebElementEntity>
