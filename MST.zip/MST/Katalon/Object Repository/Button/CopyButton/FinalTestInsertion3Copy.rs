<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestInsertion3Copy</name>
   <tag></tag>
   <elementGuidId>d362d50d-ba51-4084-b1fb-aaa7c47b5dcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-panel-title[text()=&quot; Final Test &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-panel-title[text()=&quot; Final Test &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
