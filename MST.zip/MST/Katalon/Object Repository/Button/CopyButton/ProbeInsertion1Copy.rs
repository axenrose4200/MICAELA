<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeInsertion1Copy</name>
   <tag></tag>
   <elementGuidId>16d18892-fa2c-4d21-8f12-5bb5f6f7a510</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;]</value>
   </webElementProperties>
</WebElementEntity>
