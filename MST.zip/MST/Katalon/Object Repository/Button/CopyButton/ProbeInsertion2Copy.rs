<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeInsertion2Copy</name>
   <tag></tag>
   <elementGuidId>8b72dd3e-55e2-4f9c-b074-6b13496596b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
