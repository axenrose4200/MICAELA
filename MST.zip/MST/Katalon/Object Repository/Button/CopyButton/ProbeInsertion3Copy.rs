<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeInsertion3Copy</name>
   <tag></tag>
   <elementGuidId>62e17146-32c8-4250-8603-fd986c7c72ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-panel-title[text()=&quot; Probe &quot;]//ancestor::mat-expansion-panel-header//following-sibling::div//div//mat-action-row//button//span//mat-icon[text()=&quot;file_copy&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
