<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutomotiveFlagDisabled</name>
   <tag></tag>
   <elementGuidId>44376a9f-d6ed-4a50-b4a1-6331da0f5326</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Automotive: NO &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Automotive: NO &quot;]</value>
   </webElementProperties>
</WebElementEntity>
