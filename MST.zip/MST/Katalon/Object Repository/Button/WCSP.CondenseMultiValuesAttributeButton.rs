<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.CondenseMultiValuesAttributeButton</name>
   <tag></tag>
   <elementGuidId>0a976fd5-8130-4bcb-9647-3bbace5c97d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
