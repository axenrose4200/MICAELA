<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>YesPrompt</name>
   <tag></tag>
   <elementGuidId>cc6c02b0-851a-45ae-85c3-b0247bbfb9ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@class=&quot;mat-button-wrapper&quot; and text() = &quot;Yes&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class=&quot;mat-button-wrapper&quot; and text() = &quot;Yes&quot;]</value>
   </webElementProperties>
</WebElementEntity>
