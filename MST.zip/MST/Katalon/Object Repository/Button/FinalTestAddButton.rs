<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestAddButton</name>
   <tag></tag>
   <elementGuidId>87800de3-268a-4909-bc68-955746811dca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[text()=&quot; Final Test &quot;]//parent::span//parent::mat-expansion-panel-header//following-sibling::div//mat-action-row//button//span//mat-icon[text()=&quot;add&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[text()=&quot; Final Test &quot;]//parent::span//parent::mat-expansion-panel-header//following-sibling::div//mat-action-row//button//span//mat-icon[text()=&quot;add&quot;]</value>
   </webElementProperties>
</WebElementEntity>
