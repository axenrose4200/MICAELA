<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ResetAllFiltersButton</name>
   <tag></tag>
   <elementGuidId>6cf8e04c-f8e3-47de-82db-1ee7b8bb6c51</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-icon[@aria-label=&quot;Reset All&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-icon[@aria-label=&quot;Reset All&quot;]</value>
   </webElementProperties>
</WebElementEntity>
