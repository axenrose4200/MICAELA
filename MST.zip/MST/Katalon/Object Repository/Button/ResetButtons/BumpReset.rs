<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpReset</name>
   <tag></tag>
   <elementGuidId>13dfd13b-80ba-4c22-8b2b-bec3015d2203</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
