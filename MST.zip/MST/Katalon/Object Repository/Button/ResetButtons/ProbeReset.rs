<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeReset</name>
   <tag></tag>
   <elementGuidId>cf95c461-0012-4f40-9549-fdb6e07d7727</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
