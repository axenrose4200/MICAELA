<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BacksideReset</name>
   <tag></tag>
   <elementGuidId>d1f52d76-466c-4311-a641-1c0b18ac6503</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
