<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestReset</name>
   <tag></tag>
   <elementGuidId>a7158ce2-066d-4108-9435-4eff887170f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[6]</value>
   </webElementProperties>
</WebElementEntity>
