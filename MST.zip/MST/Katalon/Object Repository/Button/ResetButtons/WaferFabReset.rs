<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WaferFabReset</name>
   <tag></tag>
   <elementGuidId>d2a03fc6-02d4-4361-88d1-78c999f455df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@aria-label=&quot;Clear Filters&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
