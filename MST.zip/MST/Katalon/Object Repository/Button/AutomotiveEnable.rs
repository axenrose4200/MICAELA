<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutomotiveEnable</name>
   <tag></tag>
   <elementGuidId>b1d92c88-be7f-4aa3-a7cf-ed8a183eda50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Automotive: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Automotive: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
   </webElementProperties>
</WebElementEntity>
