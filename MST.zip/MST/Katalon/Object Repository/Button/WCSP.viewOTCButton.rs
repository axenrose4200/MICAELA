<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.viewOTCButton</name>
   <tag></tag>
   <elementGuidId>8ab8bbd0-9b46-4414-83ae-1e7f6b8db6ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class=&quot;mat-raised-button ng-star-inserted&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
