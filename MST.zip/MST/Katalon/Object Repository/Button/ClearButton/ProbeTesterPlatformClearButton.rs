<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeTesterPlatformClearButton</name>
   <tag></tag>
   <elementGuidId>6a8bbc37-199b-4adc-a41f-93745242e90c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@placeholder=&quot;Tester Platform&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@placeholder=&quot;Tester Platform&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
   </webElementProperties>
</WebElementEntity>
