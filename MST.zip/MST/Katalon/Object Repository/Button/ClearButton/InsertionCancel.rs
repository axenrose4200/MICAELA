<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>InsertionCancel</name>
   <tag></tag>
   <elementGuidId>80d75560-5d18-4e62-90e1-fb84905e9eac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[text()=&quot; INSERTION 1 &quot;]//button//span//mat-icon[text()=&quot;cancel&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[text()=&quot; INSERTION 1 &quot;]//button//span//mat-icon[text()=&quot;cancel&quot;]</value>
   </webElementProperties>
</WebElementEntity>
