<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeTestTemperatureClearButton</name>
   <tag></tag>
   <elementGuidId>051b5f9a-c60f-497b-adf8-a5fa38a240ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@placeholder=&quot;Test Temperature&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@placeholder=&quot;Test Temperature&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
   </webElementProperties>
</WebElementEntity>
