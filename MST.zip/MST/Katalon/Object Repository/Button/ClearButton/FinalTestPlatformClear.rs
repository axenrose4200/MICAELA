<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestPlatformClear</name>
   <tag></tag>
   <elementGuidId>d62f6695-a414-4241-b349-44a7492abb2e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@placeholder=&quot;Tester Platform&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@placeholder=&quot;Tester Platform&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
   </webElementProperties>
</WebElementEntity>
