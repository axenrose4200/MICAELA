<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestTemperatureClear</name>
   <tag></tag>
   <elementGuidId>f59b3e62-bffd-4db5-86b8-984cb800bc82</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@placeholder=&quot;Test Temperature&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@placeholder=&quot;Test Temperature&quot;]//parent::div//following-sibling::div//child::mat-icon[text()=&quot;cancel&quot;]</value>
   </webElementProperties>
</WebElementEntity>
