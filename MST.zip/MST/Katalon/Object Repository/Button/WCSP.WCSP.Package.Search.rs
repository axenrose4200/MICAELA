<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.WCSP.Package.Search</name>
   <tag></tag>
   <elementGuidId>bcf99702-f795-4717-974c-fa9cb0cb1fc3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;wcsp-title mat-expansion-panel-header-title&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;wcsp-title mat-expansion-panel-header-title&quot;]</value>
   </webElementProperties>
</WebElementEntity>
