<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WettableEnable</name>
   <tag></tag>
   <elementGuidId>47be611b-000a-422a-93aa-b9bb7a21cacf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Wettable Flanks: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Wettable Flanks: NO &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
   </webElementProperties>
</WebElementEntity>
