<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Burn-inDisable</name>
   <tag></tag>
   <elementGuidId>2e81b3a8-b4cd-4c2e-9794-083d15ffc829</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Burn-in: YES &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Burn-in: YES &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
   </webElementProperties>
</WebElementEntity>
