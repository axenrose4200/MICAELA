<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>shareURL.WCSP</name>
   <tag></tag>
   <elementGuidId>9a7cd661-cd3c-44d6-b5a3-e3c641a40a7c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;primary mat-raised-button mat-primary&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;primary mat-raised-button mat-primary&quot;]</value>
   </webElementProperties>
</WebElementEntity>
