<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>save.SaveAsNew</name>
   <tag></tag>
   <elementGuidId>100f8e3c-84ae-422c-aa9f-2a60de371c78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;mat-raised-button mat-primary&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;mat-raised-button mat-primary&quot;]</value>
   </webElementProperties>
</WebElementEntity>
