<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Copy Link Icon</name>
   <tag></tag>
   <elementGuidId>31dcfebd-39ef-4dd3-ba21-ce3b2dc64048</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;mat-icon notranslate material-icons mat-icon-no-color&quot;])[59]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;mat-icon notranslate material-icons mat-icon-no-color&quot;])[59]</value>
   </webElementProperties>
</WebElementEntity>
