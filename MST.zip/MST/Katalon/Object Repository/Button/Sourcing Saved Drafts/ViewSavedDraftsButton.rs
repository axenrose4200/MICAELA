<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ViewSavedDraftsButton</name>
   <tag></tag>
   <elementGuidId>ab78b1f7-0a1c-495e-8386-bcd90f99c826</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;mat-icon-button ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;mat-icon-button ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
