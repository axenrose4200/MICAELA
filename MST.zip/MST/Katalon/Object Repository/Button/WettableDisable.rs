<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WettableDisable</name>
   <tag></tag>
   <elementGuidId>7f990c4e-0d1e-41cf-8819-7fba1703ed33</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot; Wettable Flanks: YES &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot; Wettable Flanks: YES &quot;]//parent::label//div//div[@class=&quot;mat-slide-toggle-thumb-container&quot;]</value>
   </webElementProperties>
</WebElementEntity>
