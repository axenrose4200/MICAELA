<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FilterRequired</name>
   <tag></tag>
   <elementGuidId>0802ebf4-9f73-404f-8288-5a422e7db12d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-card[text()=&quot; Please define product attributes to continue &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-card[text()=&quot; Please define product attributes to continue &quot;]</value>
   </webElementProperties>
</WebElementEntity>
