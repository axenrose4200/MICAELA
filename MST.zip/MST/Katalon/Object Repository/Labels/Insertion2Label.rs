<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Tab</description>
   <name>Insertion2Label</name>
   <tag></tag>
   <elementGuidId>7760410e-66c7-457c-a5ce-9b2173b40fa2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot; INSERTION 2 &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot; INSERTION 2 &quot;]</value>
   </webElementProperties>
</WebElementEntity>
