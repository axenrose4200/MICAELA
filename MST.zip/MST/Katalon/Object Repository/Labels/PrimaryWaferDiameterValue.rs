<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PrimaryWaferDiameterValue</name>
   <tag></tag>
   <elementGuidId>dfecd0d8-212c-48b9-a684-60e9dd7dfa5d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-label[@class=&quot;ng-star-inserted&quot; and text()=&quot;Primary Wafer Diameter&quot;]//parent::label//parent::span//parent::div//child::input[@class=&quot;mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-label[@class=&quot;ng-star-inserted&quot; and text()=&quot;Primary Wafer Diameter&quot;]//parent::label//parent::span//parent::div//child::input[@class=&quot;mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
