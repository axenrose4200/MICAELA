<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Tab</description>
   <name>Insertion1Label</name>
   <tag></tag>
   <elementGuidId>03c33fd8-1b97-4fd3-9aaa-452511a49eb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot; INSERTION 1 &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot; INSERTION 1 &quot;]</value>
   </webElementProperties>
</WebElementEntity>
