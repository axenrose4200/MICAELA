<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MaxDieYFilter</name>
   <tag></tag>
   <elementGuidId>9d25522f-698c-413e-86bb-e3db923416fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//strong[contains(text(),&quot;Y&quot;) and contains(text(),&quot;Max Die&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//strong[contains(text(),&quot;Y&quot;) and contains(text(),&quot;Max Die&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Labels/iFrame</value>
   </webElementProperties>
</WebElementEntity>
