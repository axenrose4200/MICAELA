<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SourcingSelectionBanner</name>
   <tag></tag>
   <elementGuidId>7ece4ebb-c6a6-40a8-a9b5-df5d3dd2bde5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot;MST Staging – Sourcing Selection &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot;MST Staging – Sourcing Selection &quot;]</value>
   </webElementProperties>
</WebElementEntity>
