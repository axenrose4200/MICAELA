<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WaferDiameterLabel</name>
   <tag></tag>
   <elementGuidId>e959407a-d072-45ca-8097-49625abf49fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@class=&quot;mat-cell cdk-column-column mat-column-column ng-star-inserted&quot; and text()=&quot; Wafer Diameter &quot;]//parent::td//following-sibling::td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@class=&quot;mat-cell cdk-column-column mat-column-column ng-star-inserted&quot; and text()=&quot; Wafer Diameter &quot;]//parent::td//following-sibling::td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
