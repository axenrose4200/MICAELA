<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LeadframeFinishFilter</name>
   <tag></tag>
   <elementGuidId>d510505e-c0fa-48c6-8026-e207fa866867</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//strong[contains(text(),&quot;Leadframe Finish&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//strong[contains(text(),&quot;Leadframe Finish&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Labels/iFrame</value>
   </webElementProperties>
</WebElementEntity>
