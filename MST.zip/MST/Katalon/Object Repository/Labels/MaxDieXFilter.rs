<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MaxDieXFilter</name>
   <tag></tag>
   <elementGuidId>d1bc37e7-69ff-4e83-9a9f-d6b029038a3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//strong[contains(text(),&quot;X&quot;) and contains(text(),&quot;Max Die&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//strong[contains(text(),&quot;X&quot;) and contains(text(),&quot;Max Die&quot;)]//ancestor::td[@class=&quot;label&quot;]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Labels/iFrame</value>
   </webElementProperties>
</WebElementEntity>
