<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpCB</name>
   <tag></tag>
   <elementGuidId>107bf4fd-a25d-4aea-9e97-baad6f9eb31d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
