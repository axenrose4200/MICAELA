<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeCB</name>
   <tag></tag>
   <elementGuidId>8249b65c-ddd0-4757-8943-336185a2eb1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
