<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpSourcingChecked</name>
   <tag></tag>
   <elementGuidId>c96c378e-e567-43ba-90da-7a3b1feeee45</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[9]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[9]</value>
   </webElementProperties>
</WebElementEntity>
