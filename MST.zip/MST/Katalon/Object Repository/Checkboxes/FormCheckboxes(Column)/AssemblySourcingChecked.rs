<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssemblySourcingChecked</name>
   <tag></tag>
   <elementGuidId>ea1b2203-a726-4ddf-a68d-1a6780bc4a0e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[10]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[10]</value>
   </webElementProperties>
</WebElementEntity>
