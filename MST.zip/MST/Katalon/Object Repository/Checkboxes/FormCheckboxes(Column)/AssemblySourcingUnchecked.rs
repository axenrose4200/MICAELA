<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssemblySourcingUnchecked</name>
   <tag></tag>
   <elementGuidId>a3ef7b64-fecd-4874-8d36-5ae9cdced9d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[12]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @aria-checked=&quot;true&quot;])[12]</value>
   </webElementProperties>
</WebElementEntity>
