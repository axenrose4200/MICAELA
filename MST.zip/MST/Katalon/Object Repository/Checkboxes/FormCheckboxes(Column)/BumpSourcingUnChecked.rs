<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpSourcingUnChecked</name>
   <tag></tag>
   <elementGuidId>b00c15da-65f9-4e82-ac50-f69127ac9293</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @id=&quot;mat-checkbox-6-input&quot; and @aria-checked=&quot;false&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@class=&quot;mat-checkbox-input cdk-visually-hidden&quot; and @id=&quot;mat-checkbox-6-input&quot; and @aria-checked=&quot;false&quot;]</value>
   </webElementProperties>
</WebElementEntity>
