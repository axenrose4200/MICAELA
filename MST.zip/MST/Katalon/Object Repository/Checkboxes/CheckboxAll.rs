<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckboxAll</name>
   <tag></tag>
   <elementGuidId>97768b36-2c54-4b09-8ee5-577506e2ad65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class=&quot;ui-chkbox-box ui-widget ui-state-default&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class=&quot;ui-chkbox-box ui-widget ui-state-default&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
