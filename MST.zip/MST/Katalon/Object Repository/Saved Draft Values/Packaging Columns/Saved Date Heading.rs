<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Saved Date Heading</name>
   <tag></tag>
   <elementGuidId>97da9d49-6ac3-4382-9456-7ac6eacc5469</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class=&quot;mat-header-cell cdk-column-revisiondate mat-column-revisiondate mat-table-sticky ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class=&quot;mat-header-cell cdk-column-revisiondate mat-column-revisiondate mat-table-sticky ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
