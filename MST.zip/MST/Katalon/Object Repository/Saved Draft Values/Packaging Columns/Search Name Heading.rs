<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search Name Heading</name>
   <tag></tag>
   <elementGuidId>ef98efd0-33ac-4937-b783-c90b1899430b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-sort-header-container&quot;]//*[contains(text(), &quot;Search Name&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-sort-header-container&quot;]//*[contains(text(), &quot;Search Name&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
