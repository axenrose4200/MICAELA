<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Items</name>
   <tag></tag>
   <elementGuidId>691ae0fd-7c8a-490c-b0e5-31fa4cff770a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
