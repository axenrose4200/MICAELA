<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Revisions Heading</name>
   <tag></tag>
   <elementGuidId>76c11a53-3ccf-4044-b8ad-a39cfcfb6dfc</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
