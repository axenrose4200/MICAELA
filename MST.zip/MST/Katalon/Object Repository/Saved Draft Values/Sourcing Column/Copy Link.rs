<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Copy Link</name>
   <tag></tag>
   <elementGuidId>f5504d2e-51f0-414f-8209-c83236c1ba1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class=&quot;max-w mat-header-cell cdk-column-copy mat-column-copy mat-table-sticky ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class=&quot;max-w mat-header-cell cdk-column-copy mat-column-copy mat-table-sticky ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
