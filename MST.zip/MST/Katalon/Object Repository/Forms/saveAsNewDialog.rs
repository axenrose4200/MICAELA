<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>saveAsNewDialog</name>
   <tag></tag>
   <elementGuidId>734e98e7-a016-4499-8828-55144eb64f48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-dialog-container[@class=&quot;mat-dialog-container ng-tns-c76-143 ng-trigger ng-trigger-dialogContainer ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
