<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OTCSearchForm</name>
   <tag></tag>
   <elementGuidId>2a49eecc-5b4f-47ac-ac0f-3a36cd2fd8c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;otc-title mat-expansion-panel-header-title&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;otc-title mat-expansion-panel-header-title&quot;]</value>
   </webElementProperties>
</WebElementEntity>
