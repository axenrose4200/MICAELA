<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.packagesearchForm</name>
   <tag></tag>
   <elementGuidId>7e830bbf-43a7-4d3b-a958-1e5a9bd255f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//form[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//form[@class=&quot;ng-untouched ng-pristine ng-valid&quot;]</value>
   </webElementProperties>
</WebElementEntity>
