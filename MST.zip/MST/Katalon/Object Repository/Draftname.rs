<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Draftname</name>
   <tag></tag>
   <elementGuidId>3fb3c74f-5def-4550-b37b-1ca87cf2eebc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h4[text()=&quot;Draft 1 - &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h4[text()=&quot;Draft 1 - &quot;]</value>
   </webElementProperties>
</WebElementEntity>
