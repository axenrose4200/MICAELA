<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SourcingPlanNoReviewRequired</name>
   <tag></tag>
   <elementGuidId>bd4ae07a-a92f-42bd-86a8-a75ed16a5e48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[@class=&quot;ng-tns-c45-4&quot; and text()=&quot;Assembly&quot;]//parent::p//parent::td//following-sibling::td//p//b[text()=&quot;No Review Required&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//b[@class=&quot;ng-tns-c45-4&quot; and text()=&quot;Assembly&quot;]//parent::p//parent::td//following-sibling::td//p//b[text()=&quot;No Review Required&quot;]</value>
   </webElementProperties>
</WebElementEntity>
