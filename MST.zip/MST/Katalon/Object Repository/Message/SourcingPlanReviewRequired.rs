<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SourcingPlanReviewRequired</name>
   <tag></tag>
   <elementGuidId>f2971ae2-90be-4f8f-9a71-52dd3f172590</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[@class=&quot;ng-tns-c45-4&quot; and text()=&quot;Assembly&quot;]//parent::p//parent::td//following-sibling::td//p//b[text()=&quot;Review Required&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//b[@class=&quot;ng-tns-c45-4&quot; and text()=&quot;Assembly&quot;]//parent::p//parent::td//following-sibling::td//p//b[text()=&quot;Review Required&quot;]</value>
   </webElementProperties>
</WebElementEntity>
