<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>home title</name>
   <tag></tag>
   <elementGuidId>58f64da0-0b66-47b6-9b3e-75a48f830403</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ti-page-title[text()=&quot;Manufacturing Selection Tool &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ti-page-title[text()=&quot;Manufacturing Selection Tool &quot;]</value>
   </webElementProperties>
</WebElementEntity>
