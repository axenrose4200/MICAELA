<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel8</name>
   <tag></tag>
   <elementGuidId>e4ddefeb-4fbf-4070-a879-19e81265f84a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h2[contains(text(),&quot;What's coming for MST:&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h2[contains(text(),&quot;What's coming for MST:&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
