<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel1</name>
   <tag></tag>
   <elementGuidId>30f4c40c-3865-40c5-9a44-e11a37a63e39</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[contains(text(),&quot;Welcome to the Manufacturing Selection Tool (MST)&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//b[contains(text(),&quot;Welcome to the Manufacturing Selection Tool (MST)&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
