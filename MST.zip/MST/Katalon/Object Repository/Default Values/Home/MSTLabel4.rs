<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel4</name>
   <tag></tag>
   <elementGuidId>84c56ded-9726-4e52-9b3e-7e229db0ddaa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[contains(text(),&quot;Easily analyze key costing and maximum die size information for existing packages&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[contains(text(),&quot;Easily analyze key costing and maximum die size information for existing packages&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
