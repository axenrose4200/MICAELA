<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel3</name>
   <tag></tag>
   <elementGuidId>83b1f419-d219-405a-8108-0e5e3da663ad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h2[contains(text(),&quot;With this analysis tool, you'll be able to:&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h2[contains(text(),&quot;With this analysis tool, you'll be able to:&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
