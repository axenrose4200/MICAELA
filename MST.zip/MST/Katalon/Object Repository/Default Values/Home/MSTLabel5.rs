<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel5</name>
   <tag></tag>
   <elementGuidId>e4dc13b2-6fbd-4741-8f63-9a60d2da8845</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[contains(text(),&quot;Maximize the reuse of existing packages&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[contains(text(),&quot;Maximize the reuse of existing packages&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
