<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel2</name>
   <tag></tag>
   <elementGuidId>6f3bc688-78aa-4299-8eab-9b63e72c14a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//p[contains(text(),&quot; Manufacturing Selection Tool (MST) is targeted to be a one stop shop tool for package and sourcing selection analysis needs. &quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//p[contains(text(),&quot; Manufacturing Selection Tool (MST) is targeted to be a one stop shop tool for package and sourcing selection analysis needs. &quot;)]</value>
   </webElementProperties>
</WebElementEntity>
