<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel11</name>
   <tag></tag>
   <elementGuidId>3570ae06-d469-4b5c-9a50-dc941c2ee81b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[contains(text(),&quot;Interdependent factory checks for Sourcing strategy&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[contains(text(),&quot;Interdependent factory checks for Sourcing strategy&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
