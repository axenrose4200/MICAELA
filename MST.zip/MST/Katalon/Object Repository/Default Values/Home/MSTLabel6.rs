<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel6</name>
   <tag></tag>
   <elementGuidId>d83435f0-3320-43cb-a92a-ee5c07ff536e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[contains(text(),&quot;Analyze optimal sourcing selection formation manufacturing flow based on product info&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[contains(text(),&quot;Analyze optimal sourcing selection formation manufacturing flow based on product info&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
