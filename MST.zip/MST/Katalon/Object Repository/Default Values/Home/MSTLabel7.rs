<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel7</name>
   <tag></tag>
   <elementGuidId>65516cab-6073-4544-95d8-be1786fae355</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//p[contains(text(),&quot; Click on the menu icon in the left corner to get started&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//p[contains(text(),&quot; Click on the menu icon in the left corner to get started&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
