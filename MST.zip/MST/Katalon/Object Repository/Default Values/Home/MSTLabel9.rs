<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>MSTLabel9</name>
   <tag></tag>
   <elementGuidId>69b65a34-3c7d-4f03-b0eb-0aab9d454b02</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//li[contains(text(),&quot;Additional filters for automotive applications&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//li[contains(text(),&quot;Additional filters for automotive applications&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
