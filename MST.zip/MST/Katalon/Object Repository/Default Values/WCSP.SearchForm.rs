<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.SearchForm</name>
   <tag></tag>
   <elementGuidId>811ac1ee-4722-4262-a045-9d672f66db77</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-expansion-panel-content ng-trigger ng-trigger-bodyExpansion&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-expansion-panel-content ng-trigger ng-trigger-bodyExpansion&quot;]</value>
   </webElementProperties>
</WebElementEntity>
