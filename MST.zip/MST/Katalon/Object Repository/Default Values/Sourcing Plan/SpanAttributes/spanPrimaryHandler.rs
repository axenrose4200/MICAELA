<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>spanPrimaryHandler</name>
   <tag></tag>
   <elementGuidId>84552d99-1200-4716-aa34-f55e0a74532b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[11]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[11]</value>
   </webElementProperties>
</WebElementEntity>
