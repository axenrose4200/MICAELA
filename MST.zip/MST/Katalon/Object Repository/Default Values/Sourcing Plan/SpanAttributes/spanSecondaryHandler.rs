<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>spanSecondaryHandler</name>
   <tag></tag>
   <elementGuidId>0e9b20a5-378c-4a28-b836-3ad6241a8213</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[12]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[12]</value>
   </webElementProperties>
</WebElementEntity>
