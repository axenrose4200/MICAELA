<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>spanPackageGrp</name>
   <tag></tag>
   <elementGuidId>e4e7206f-6e76-40ef-97ab-8b6bb6a7cdd6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[8]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[8]</value>
   </webElementProperties>
</WebElementEntity>
