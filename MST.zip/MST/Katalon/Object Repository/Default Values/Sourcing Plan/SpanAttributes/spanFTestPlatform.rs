<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>spanFTestPlatform</name>
   <tag></tag>
   <elementGuidId>da52bf0e-3af3-4b3b-ac09-94af4e3b848c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[10]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[10]</value>
   </webElementProperties>
</WebElementEntity>
