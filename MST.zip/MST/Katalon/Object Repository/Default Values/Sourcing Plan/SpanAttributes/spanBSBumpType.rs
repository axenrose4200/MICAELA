<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>spanBSBumpType</name>
   <tag></tag>
   <elementGuidId>840bd891-92c4-4d4e-a71b-26c8073ac992</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
