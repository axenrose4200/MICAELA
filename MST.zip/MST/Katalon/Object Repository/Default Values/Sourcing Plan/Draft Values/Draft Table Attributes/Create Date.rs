<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Create Date</name>
   <tag></tag>
   <elementGuidId>1740d0f3-163b-41bd-823e-9e87d3023254</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class=&quot;mat-header-cell cdk-column-createdon mat-column-createdon mat-table-sticky ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class=&quot;mat-header-cell cdk-column-createdon mat-column-createdon mat-table-sticky ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
