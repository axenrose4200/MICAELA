<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Revisions</name>
   <tag></tag>
   <elementGuidId>e8cfa5ec-481f-499a-8518-99c398744851</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class=&quot;mat-header-cell cdk-column-revisioncount mat-column-revisioncount mat-table-sticky ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class=&quot;mat-header-cell cdk-column-revisioncount mat-column-revisioncount mat-table-sticky ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
