<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Revision Saved Date</name>
   <tag></tag>
   <elementGuidId>5d171a84-8494-49cb-bf1d-2a259bdce66f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[@class=&quot;mat-header-cell cdk-column-revisiondate mat-column-revisiondate mat-table-sticky ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[@class=&quot;mat-header-cell cdk-column-revisiondate mat-column-revisiondate mat-table-sticky ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
