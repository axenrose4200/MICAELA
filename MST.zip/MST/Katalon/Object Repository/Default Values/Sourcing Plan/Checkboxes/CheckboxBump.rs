<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckboxBump</name>
   <tag></tag>
   <elementGuidId>755916f8-ed3d-43c4-aade-afbb3d25aafe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
