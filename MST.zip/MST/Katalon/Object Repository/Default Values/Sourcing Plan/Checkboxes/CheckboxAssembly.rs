<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckboxAssembly</name>
   <tag></tag>
   <elementGuidId>2cd07c2e-c847-49df-a040-1e3da628ba49</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[5]</value>
   </webElementProperties>
</WebElementEntity>
