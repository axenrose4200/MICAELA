<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CheckboxProbe</name>
   <tag></tag>
   <elementGuidId>566d5202-4243-44b0-ac23-adcba6718437</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
