<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Expand5</name>
   <tag></tag>
   <elementGuidId>817951a7-f1b1-4118-958f-ac083537b9ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[5]</value>
   </webElementProperties>
</WebElementEntity>
