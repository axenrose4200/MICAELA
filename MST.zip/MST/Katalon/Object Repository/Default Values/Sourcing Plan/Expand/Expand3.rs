<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Expand3</name>
   <tag></tag>
   <elementGuidId>b9ca78d0-2351-40c6-8478-cd63d9e3f833</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
