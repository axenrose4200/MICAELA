<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Expand1</name>
   <tag></tag>
   <elementGuidId>d84582a9-a3bb-44d9-8c2e-9097059a933f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
