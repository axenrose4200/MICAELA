<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Expand6</name>
   <tag></tag>
   <elementGuidId>1b154852-3306-4edb-9231-9ecce9ea29ef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[6]</value>
   </webElementProperties>
</WebElementEntity>
