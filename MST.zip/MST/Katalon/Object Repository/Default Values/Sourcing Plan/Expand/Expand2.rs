<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Expand2</name>
   <tag></tag>
   <elementGuidId>827f08f3-c348-4133-b124-6bce047f78a6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-icon[@class=&quot;expandIndicator mat-icon ng-tns-c45-4 material-icons ng-star-inserted&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
