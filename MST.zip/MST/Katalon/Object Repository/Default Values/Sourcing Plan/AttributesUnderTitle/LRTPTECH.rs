<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LRTPTECH</name>
   <tag></tag>
   <elementGuidId>8ac9c4a8-50f6-4813-b48f-85b6a97a8ccb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;]//following-sibling::tr[@class=&quot;mat-row ng-tns-c45-4 detail-row not-included ng-star-inserted&quot;]//ancestor::b[text()=&quot;LRPTECH:&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//tr[@class=&quot;mat-row ng-tns-c45-4 not-included ng-star-inserted&quot;]//following-sibling::tr[@class=&quot;mat-row ng-tns-c45-4 detail-row not-included ng-star-inserted&quot;]//ancestor::b[text()=&quot;LRPTECH:&quot;]</value>
   </webElementProperties>
</WebElementEntity>
