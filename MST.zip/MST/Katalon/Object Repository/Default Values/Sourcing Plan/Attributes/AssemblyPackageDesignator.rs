<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssemblyPackageDesignator</name>
   <tag></tag>
   <elementGuidId>f2c3f123-3f04-4075-b5bc-d976b3c8b254</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[text()=&quot;Package Designator:&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//b[text()=&quot;Package Designator:&quot;]</value>
   </webElementProperties>
</WebElementEntity>
