<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeTestTemperatureAttribute</name>
   <tag></tag>
   <elementGuidId>15f9a0c0-d99a-450a-a38c-83e1321ed628</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//b[text()=&quot;Test Temperature:&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//b[text()=&quot;Test Temperature:&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
