<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestTemperature</name>
   <tag></tag>
   <elementGuidId>a75483b4-f5c6-4b03-8fc9-145c5d85035b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//b[text()=&quot;Test Temperature:&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//b[text()=&quot;Test Temperature:&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
