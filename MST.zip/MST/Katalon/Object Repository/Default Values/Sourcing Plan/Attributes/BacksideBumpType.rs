<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BacksideBumpType</name>
   <tag></tag>
   <elementGuidId>b12df997-6443-4a70-890f-76112062f9e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//b[text()=&quot;Bump Type:&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//b[text()=&quot;Bump Type:&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
