<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FINALTESTTesterPlatform</name>
   <tag></tag>
   <elementGuidId>00fede24-ee4e-4f14-84a0-8a2a6d89ac28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//b[text()=&quot;Tester Platform:&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//b[text()=&quot;Tester Platform:&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
