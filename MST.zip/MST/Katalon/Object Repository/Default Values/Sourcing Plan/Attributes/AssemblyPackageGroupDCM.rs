<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssemblyPackageGroupDCM</name>
   <tag></tag>
   <elementGuidId>4d2ae462-5c25-4bd5-8d1d-b249b2d90856</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//b[text()=&quot;Package Group DCM:&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//b[text()=&quot;Package Group DCM:&quot;]</value>
   </webElementProperties>
</WebElementEntity>
