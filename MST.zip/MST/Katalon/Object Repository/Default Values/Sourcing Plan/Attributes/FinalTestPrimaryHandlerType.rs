<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestPrimaryHandlerType</name>
   <tag></tag>
   <elementGuidId>d74bcb85-1161-492c-b941-95a58b44dc6b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//b[text()=&quot;Primary Handler Type:&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//b[text()=&quot;Primary Handler Type:&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
