<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>packageDesignator</name>
   <tag></tag>
   <elementGuidId>8c9076e1-6ee3-4543-9afd-0787d6eed0ee</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
