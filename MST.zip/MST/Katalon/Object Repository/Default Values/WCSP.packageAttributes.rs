<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WCSP.packageAttributes</name>
   <tag></tag>
   <elementGuidId>b700b730-31a4-4167-97bc-e3d8eb42880e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//th[contains(text(), &quot;Package Attributes&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//th[contains(text(), &quot;Package Attributes&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
