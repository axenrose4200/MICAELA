<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Max4QTREmpty</name>
   <tag></tag>
   <elementGuidId>5b5baeea-9471-45b2-9a06-18b7f0ee0b61</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[@class=&quot;mat-form-field-label ng-tns-c47-17 ng-star-inserted mat-empty mat-form-field-empty&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[@class=&quot;mat-form-field-label ng-tns-c47-17 ng-star-inserted mat-empty mat-form-field-empty&quot;]</value>
   </webElementProperties>
</WebElementEntity>
