<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ChipsPerWaferEmpty</name>
   <tag></tag>
   <elementGuidId>f520268f-3590-4e52-a221-60483379530a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[@class=&quot;mat-form-field-label ng-tns-c47-18 ng-star-inserted mat-empty mat-form-field-empty&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[@class=&quot;mat-form-field-label ng-tns-c47-18 ng-star-inserted mat-empty mat-form-field-empty&quot;]</value>
   </webElementProperties>
</WebElementEntity>
