<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>attributeGroups.WCSP</name>
   <tag></tag>
   <elementGuidId>4d0015a1-23df-48cb-8d3a-2eb6abae4e79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(), &quot;Select attribute groups&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(), &quot;Select attribute groups&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
