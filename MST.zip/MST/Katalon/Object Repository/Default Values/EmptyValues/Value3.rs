<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Value3</name>
   <tag></tag>
   <elementGuidId>e24e76c2-b105-4abb-a776-fa2f1c6f22d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
