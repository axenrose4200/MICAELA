<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Value7</name>
   <tag></tag>
   <elementGuidId>3a264659-eb4b-4405-b0bb-f289c94a5ed0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[7]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[7]</value>
   </webElementProperties>
</WebElementEntity>
