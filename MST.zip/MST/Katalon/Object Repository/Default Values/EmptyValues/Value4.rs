<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Value4</name>
   <tag></tag>
   <elementGuidId>c98d23d3-e534-499e-845a-b79852f07110</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
