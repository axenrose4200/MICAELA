<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Value1</name>
   <tag></tag>
   <elementGuidId>12826de5-4a19-433f-a4d2-08f2b6b39574</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
