<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Value6</name>
   <tag></tag>
   <elementGuidId>e106acb5-9ab4-4f0e-9d8d-16541e24e568</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-primaryValue mat-column-primaryValue ng-star-inserted&quot;])[6]</value>
   </webElementProperties>
</WebElementEntity>
