<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpTab</name>
   <tag></tag>
   <elementGuidId>86ce00e2-2877-4a91-90eb-550a3062b5b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Bump&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Bump&quot;]</value>
   </webElementProperties>
</WebElementEntity>
