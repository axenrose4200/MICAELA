<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Wafer Fab Tab</name>
   <tag></tag>
   <elementGuidId>2d8c1d50-2c3f-4882-9af3-f11a6ed6dfa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[text()=&quot; Wafer Fab &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[text()=&quot; Wafer Fab &quot;]</value>
   </webElementProperties>
</WebElementEntity>
