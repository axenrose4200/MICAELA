<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PrimaryWaferDiameterWaferFab</name>
   <tag></tag>
   <elementGuidId>1b2edf5e-976a-481c-8356-40dea96074dd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-label[text()=&quot;Primary Wafer Diameter&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-label[text()=&quot;Primary Wafer Diameter&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
