<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Insertion1</name>
   <tag></tag>
   <elementGuidId>baf7423b-24d8-45d4-875b-d3d0adc98255</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//mat-panel-title[contains(text(),&quot;Insertion 1&quot;)])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//mat-panel-title[contains(text(),&quot;Insertion 1&quot;)])[2]</value>
   </webElementProperties>
</WebElementEntity>
