<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalTestBanner</name>
   <tag></tag>
   <elementGuidId>3a5a2fa7-c6f6-45d7-a71b-8a3159858900</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[contains(text(),&quot;Final Test&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[contains(text(),&quot;Final Test&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
