<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProductBanner</name>
   <tag></tag>
   <elementGuidId>5438de96-a131-42ee-abe3-8b5334e0a557</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot;Product&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot;Product&quot;]</value>
   </webElementProperties>
</WebElementEntity>
