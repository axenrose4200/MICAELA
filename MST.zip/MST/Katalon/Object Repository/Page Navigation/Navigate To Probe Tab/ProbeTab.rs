<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeTab</name>
   <tag></tag>
   <elementGuidId>e2f381fc-027a-43b3-adf3-d570a938c8cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label mat-ripple ng-star-inserted&quot;]//div[contains(text(),&quot;Probe&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label mat-ripple ng-star-inserted&quot;]//div[contains(text(),&quot;Probe&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
