<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeTabBanner</name>
   <tag></tag>
   <elementGuidId>0ce46d72-104b-4a7d-bb6c-c7cbb85b8904</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and contains(text(),&quot;Probe&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and contains(text(),&quot;Probe&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
