<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Insertion1</name>
   <tag></tag>
   <elementGuidId>f01e42f6-55b9-4c1a-b74b-619128b5f6a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and contains(text(),&quot;Insertion 1&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and contains(text(),&quot;Insertion 1&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
