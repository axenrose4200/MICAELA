<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssemblyBanner</name>
   <tag></tag>
   <elementGuidId>f922a0ef-5686-4708-b30d-7c3543e2e743</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot; Assembly &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot; Assembly &quot;]</value>
   </webElementProperties>
</WebElementEntity>
