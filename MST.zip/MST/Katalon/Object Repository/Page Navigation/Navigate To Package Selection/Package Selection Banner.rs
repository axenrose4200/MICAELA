<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Package Selection Banner</name>
   <tag></tag>
   <elementGuidId>32873634-61a9-4722-9909-223e6c69ecfe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@class=&quot;ng-star-inserted&quot; and text()=&quot;MST Staging – Package Selection &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class=&quot;ng-star-inserted&quot; and text()=&quot;MST Staging – Package Selection &quot;]</value>
   </webElementProperties>
</WebElementEntity>
