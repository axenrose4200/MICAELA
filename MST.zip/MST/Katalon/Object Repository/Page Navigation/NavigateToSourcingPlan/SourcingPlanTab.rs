<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SourcingPlanTab</name>
   <tag></tag>
   <elementGuidId>bc0c4a36-733b-4e4a-befd-76eb0085a348</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Sourcing Plan&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Sourcing Plan&quot;]</value>
   </webElementProperties>
</WebElementEntity>
