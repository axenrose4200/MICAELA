<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BacksideTab</name>
   <tag></tag>
   <elementGuidId>242d36a9-22fa-4324-b17a-a53deb3f45d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Backside&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-tab-label-content&quot; and text()=&quot;Backside&quot;]</value>
   </webElementProperties>
</WebElementEntity>
