<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BacksideBanner</name>
   <tag></tag>
   <elementGuidId>d20e5646-4d62-4397-8a7f-6b52eddb3738</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot; Backside &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[@class=&quot;mat-expansion-panel-header-title&quot; and text()=&quot; Backside &quot;]</value>
   </webElementProperties>
</WebElementEntity>
