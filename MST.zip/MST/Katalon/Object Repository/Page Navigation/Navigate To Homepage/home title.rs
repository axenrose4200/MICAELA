<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>home title</name>
   <tag></tag>
   <elementGuidId>57057e59-2811-46ae-ae77-75e730f4e7ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//ti-page-title[text()=&quot;Manufacturing Selection Tool &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//ti-page-title[text()=&quot;Manufacturing Selection Tool &quot;]</value>
   </webElementProperties>
</WebElementEntity>
