<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Details</name>
   <tag></tag>
   <elementGuidId>8952265b-f84d-40ac-87b2-bc6bb9bb4690</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;sf-element sf-element-visual-content sfc-table&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;sf-element sf-element-visual-content sfc-table&quot;]</value>
   </webElementProperties>
</WebElementEntity>
