<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectAG</name>
   <tag></tag>
   <elementGuidId>e47b8af7-abe8-4e69-b740-cf5e328f6cd6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-option[@class=&quot;mat-option ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-option[@class=&quot;mat-option ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
