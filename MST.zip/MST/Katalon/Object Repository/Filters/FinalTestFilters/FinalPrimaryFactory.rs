<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FinalPrimaryFactory</name>
   <tag></tag>
   <elementGuidId>77531c94-4a59-4580-bf27-88d490aa85b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Primary Factory&quot;])[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Primary Factory&quot;])[6]</value>
   </webElementProperties>
</WebElementEntity>
