<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FTPackageGroup</name>
   <tag></tag>
   <elementGuidId>7bcd3da3-da91-49c3-bdaf-d71c95766d6d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@placeholder = &quot;FT Package Group&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@placeholder = &quot;FT Package Group&quot;]</value>
   </webElementProperties>
</WebElementEntity>
