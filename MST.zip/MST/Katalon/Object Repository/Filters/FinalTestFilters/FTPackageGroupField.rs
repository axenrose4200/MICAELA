<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FTPackageGroupField</name>
   <tag></tag>
   <elementGuidId>7a8f57a9-70f1-41db-82d2-e0fb886568a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[text()=&quot; FT Package Group &quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[text()=&quot; FT Package Group &quot;]</value>
   </webElementProperties>
</WebElementEntity>
