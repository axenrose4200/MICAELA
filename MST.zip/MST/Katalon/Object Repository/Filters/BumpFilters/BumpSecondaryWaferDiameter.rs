<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BumpSecondaryWaferDiameter</name>
   <tag></tag>
   <elementGuidId>5bd372f4-f3b5-49c6-b8d2-54d2f4c4d5d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Secondary Wafer Diameter&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Secondary Wafer Diameter&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
