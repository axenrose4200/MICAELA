<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AutomotiveGradeField</name>
   <tag></tag>
   <elementGuidId>a623318b-664e-4dc5-aa77-b73d92c625c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot; and contains(text(),&quot; Automotive Grade&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class=&quot;ng-tns-c45-4 detailSpan ng-star-inserted&quot; and contains(text(),&quot; Automotive Grade&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
