<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>BacksideSecondaryFactory</name>
   <tag></tag>
   <elementGuidId>c7933d1a-99ce-428d-bb43-c69c8b6115a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Secondary Factory&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Secondary Factory&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
