<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>scroll</name>
   <tag></tag>
   <elementGuidId>cbc94748-1516-4c63-b872-c4e7b22aa43f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-autocomplete-panel mat-autocomplete-visible ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-autocomplete-panel mat-autocomplete-visible ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
