<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbePrimaryFactory</name>
   <tag></tag>
   <elementGuidId>1855bc9f-ca25-4c48-8098-60e0b496dfd0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Primary Factory&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Primary Factory&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
