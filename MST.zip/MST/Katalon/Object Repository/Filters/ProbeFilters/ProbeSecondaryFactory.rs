<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbeSecondaryFactory</name>
   <tag></tag>
   <elementGuidId>7ebb29f9-cd8d-4679-aa21-035da6e96ecc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Secondary Factory&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Secondary Factory&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
