<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProbePrimaryHandler</name>
   <tag></tag>
   <elementGuidId>ef5f988a-dfbc-4a35-ace4-13bfea420c9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[@placeholder=&quot;Primary Handler Type&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@placeholder=&quot;Primary Handler Type&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
