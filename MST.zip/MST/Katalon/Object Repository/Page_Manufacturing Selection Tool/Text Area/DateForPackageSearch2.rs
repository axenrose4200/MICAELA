<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DateForPackageSearch2</name>
   <tag></tag>
   <elementGuidId>44a3f062-ff5e-4ffa-a1a7-8f538dedf161</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(text(), &quot;Last Saved:&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(text(), &quot;Last Saved:&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
