<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DialogBoxDeletion</name>
   <tag></tag>
   <elementGuidId>976a6cb7-e187-4192-81ba-e721a880be69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[contains(text(), &quot;Delete drafts&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h1[contains(text(), &quot;Delete drafts&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
