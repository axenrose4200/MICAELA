<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Offset Click</name>
   <tag></tag>
   <elementGuidId>70c0fd52-90be-4b0b-b3f3-4ebd742eff62</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[@class=&quot;mat-dialog-title&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h1[@class=&quot;mat-dialog-title&quot;]</value>
   </webElementProperties>
</WebElementEntity>
