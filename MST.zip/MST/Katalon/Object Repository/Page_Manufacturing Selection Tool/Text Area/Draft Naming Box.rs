<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Draft Naming Box</name>
   <tag></tag>
   <elementGuidId>99ace8e5-9f3a-4671-bc16-f60ae80fd9ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='mat-input-49']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//div[@class=&quot;mat-form-field-outline mat-form-field-outline-thick ng-tns-c43-1043 ng-star-inserted&quot;]//div[@class=&quot;mat-form-field-infix&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class=&quot;mat-form-field-infix&quot;]//input[@class=&quot;mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-invalid ng-touched&quot;]</value>
   </webElementProperties>
</WebElementEntity>
