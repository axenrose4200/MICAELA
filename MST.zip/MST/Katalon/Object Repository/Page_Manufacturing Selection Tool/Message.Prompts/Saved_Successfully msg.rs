<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Saved_Successfully msg</name>
   <tag></tag>
   <elementGuidId>534bf3a0-3fc8-4770-9cb7-dea07cdbc961</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//simple-snack-bar[@class=&quot;mat-simple-snackbar ng-star-inserted&quot;]
</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//simple-snack-bar[@class=&quot;mat-simple-snackbar ng-star-inserted&quot;]
</value>
   </webElementProperties>
</WebElementEntity>
