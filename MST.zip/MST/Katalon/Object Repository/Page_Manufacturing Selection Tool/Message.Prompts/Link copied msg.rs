<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Link copied msg</name>
   <tag></tag>
   <elementGuidId>3c32f4fc-e115-4e86-8a09-c391262390e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//simple-snack-bar[@class=&quot;mat-simple-snackbar ng-star-inserted&quot;]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//simple-snack-bar[@class=&quot;mat-simple-snackbar ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
