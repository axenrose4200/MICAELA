<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>All Create Date</name>
   <tag></tag>
   <elementGuidId>9fd79582-4a3a-4778-a763-50318ff21004</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@class=&quot;mat-cell cdk-column-createdon mat-column-createdon ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@class=&quot;mat-cell cdk-column-createdon mat-column-createdon ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
