<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SavedSearchPackageSelection</name>
   <tag></tag>
   <elementGuidId>8d5923ab-3221-4f6a-800d-8a866f0ab480</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//button[text() = &quot;Search Name&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//button[text() = &quot;Search Name&quot;]</value>
   </webElementProperties>
</WebElementEntity>
