<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CopyWirebondPackage</name>
   <tag></tag>
   <elementGuidId>4e6013a3-917d-4fc7-aed5-6c8457ae7108</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//th[text() = &quot;Copy&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//th[text() = &quot;Copy&quot;]</value>
   </webElementProperties>
</WebElementEntity>
