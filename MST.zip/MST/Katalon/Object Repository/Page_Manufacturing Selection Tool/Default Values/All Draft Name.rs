<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>All Draft Name</name>
   <tag></tag>
   <elementGuidId>c622bc53-4a0e-4f63-be89-cde048c1b6e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
