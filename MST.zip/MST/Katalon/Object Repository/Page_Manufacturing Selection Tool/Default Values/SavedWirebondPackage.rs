<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SavedWirebondPackage</name>
   <tag></tag>
   <elementGuidId>25ad3469-da85-4403-be75-a25f5b1e2b72</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//th[text() = &quot;Saved&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()=&quot;My Saved Wirebond Package Searches&quot;]//parent::mat-card//following-sibling::div//th[text() = &quot;Saved&quot;]</value>
   </webElementProperties>
</WebElementEntity>
