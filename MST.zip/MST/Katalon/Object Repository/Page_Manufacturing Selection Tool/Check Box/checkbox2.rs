<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox2</name>
   <tag></tag>
   <elementGuidId>ddcd801b-6b40-4397-bd89-2c81f5d06022</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[3]</value>
   </webElementProperties>
</WebElementEntity>
