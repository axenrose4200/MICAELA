<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkbox3</name>
   <tag></tag>
   <elementGuidId>459cf859-fb6d-4fec-971c-2d9f870f6c63</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[@class=&quot;mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin&quot;])[4]</value>
   </webElementProperties>
</WebElementEntity>
