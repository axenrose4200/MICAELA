<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save_Sourcing_Button_DropDown</name>
   <tag></tag>
   <elementGuidId>25d22f0e-e1c1-4f29-99df-07c2e9ee8823</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;primary mat-raised-button&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;primary mat-raised-button&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
