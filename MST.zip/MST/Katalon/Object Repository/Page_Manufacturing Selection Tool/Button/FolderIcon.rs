<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FolderIcon</name>
   <tag></tag>
   <elementGuidId>ea073b2c-1e8a-4d7b-ab1c-81666c781b51</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-icon[@class=&quot;mat-icon notranslate material-icons mat-icon-no-color&quot; and text() = &quot;folder&quot;] </value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-icon[@class=&quot;mat-icon notranslate material-icons mat-icon-no-color&quot; and text() = &quot;folder&quot;] </value>
   </webElementProperties>
</WebElementEntity>
