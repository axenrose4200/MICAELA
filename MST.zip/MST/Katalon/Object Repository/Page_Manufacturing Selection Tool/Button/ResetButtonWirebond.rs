<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ResetButtonWirebond</name>
   <tag></tag>
   <elementGuidId>a0ae3a72-a715-4a10-802e-c4d84cae879a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[@class=&quot;primary mat-raised-button&quot;])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[@class=&quot;primary mat-raised-button&quot;])[2]</value>
   </webElementProperties>
</WebElementEntity>
