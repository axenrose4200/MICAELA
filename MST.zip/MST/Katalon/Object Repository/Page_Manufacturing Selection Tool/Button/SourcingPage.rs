<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SourcingPage</name>
   <tag></tag>
   <elementGuidId>cabdf233-ceba-4844-b968-35b35f3f407d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[@class=&quot;mat-tab-link mat-tab-label-active ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@class=&quot;mat-tab-link mat-tab-label-active ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
