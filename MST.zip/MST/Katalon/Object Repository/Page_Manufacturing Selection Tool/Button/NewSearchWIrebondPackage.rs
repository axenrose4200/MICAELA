<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>NewSearchWIrebondPackage</name>
   <tag></tag>
   <elementGuidId>d3084180-b3de-406b-a400-c286e4db7562</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//p[text() = &quot;New Search...&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//p[text() = &quot;New Search...&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
