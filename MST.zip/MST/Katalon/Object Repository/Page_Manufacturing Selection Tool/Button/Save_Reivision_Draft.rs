<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save_Reivision_Draft</name>
   <tag></tag>
   <elementGuidId>f1e35466-4167-4452-a80e-45f554eae7bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-button[@class=&quot;mat-menu-item ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-button[@class=&quot;mat-menu-item ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
