<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save_Draft_Name</name>
   <tag></tag>
   <elementGuidId>bf0b4352-801e-4627-9fd4-d8fb0325dd97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;primary mat-raised-button mat-primary&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@color=&quot;primary&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
