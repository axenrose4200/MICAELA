<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DraftItem</name>
   <tag></tag>
   <elementGuidId>34e5d9db-b7a4-4c01-a659-cbe232436a04</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//td[@class=&quot;mat-cell cdk-column-name mat-column-name ng-star-inserted&quot;])[1]</value>
   </webElementProperties>
</WebElementEntity>
