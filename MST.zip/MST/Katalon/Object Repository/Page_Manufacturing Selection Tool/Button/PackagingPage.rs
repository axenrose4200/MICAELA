<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PackagingPage</name>
   <tag></tag>
   <elementGuidId>dce1403d-c95f-4a14-adb1-d48d0a8c6ea3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[@class=&quot;mat-tab-link ng-star-inserted&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@class=&quot;mat-tab-link ng-star-inserted&quot;]</value>
   </webElementProperties>
</WebElementEntity>
