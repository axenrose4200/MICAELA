<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save As New_DropDown</name>
   <tag></tag>
   <elementGuidId>21f3b41d-6cd1-4429-8020-5270c175aac2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-button[text()=&quot; Save As New &quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='cdk-overlay-7']/div/div/mat-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-button[text()=&quot; Save As New &quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='cdk-overlay-7']/div/div/mat-button</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Expand All Filters'])[1]/following::mat-button[1]</value>
   </webElementXpaths>
</WebElementEntity>
