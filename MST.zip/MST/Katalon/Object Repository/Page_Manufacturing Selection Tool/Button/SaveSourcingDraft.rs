<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SaveSourcingDraft</name>
   <tag></tag>
   <elementGuidId>563f35e8-1828-4577-90ba-b5c132e06d28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;mat-raised-button mat-primary&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;mat-raised-button mat-primary&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
