<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SaveButton</name>
   <tag></tag>
   <elementGuidId>594266c7-fe0d-4c69-87aa-841f5f1524a7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@class=&quot;primary mat-raised-button&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@class=&quot;primary mat-raised-button&quot;]//*[contains(text(), &quot;Save&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
