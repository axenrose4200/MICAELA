<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>WirebondPackageSearchBanner</name>
   <tag></tag>
   <elementGuidId>a7f6e7bd-84ca-400a-a68e-5f2e842e652b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//mat-panel-title[contains(text(),' Wirebond Package Search ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//mat-panel-title[contains(text(),' Wirebond Package Search ')]</value>
   </webElementProperties>
</WebElementEntity>
