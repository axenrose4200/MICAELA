<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>NavigateToWirebondPackageSearch</name>
   <tag></tag>
   <elementGuidId>ce9b0f23-c2bd-48dc-8116-674ed1b5b342</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(),'Wirebond Package Search')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(),'Wirebond Package Search')]</value>
   </webElementProperties>
</WebElementEntity>
