import org.openqa.selenium.By as By
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DF
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Initialization'
WebDriver driver = DF.getWebDriver()

'Tick checkbox'
try {
    h2 = driver.findElement(By.xpath('//div[text()=" Select attribute groups: "]'))

        ((driver) as JavascriptExecutor).executeScript('arguments[0].scrollIntoView(true);', h2)

    WebElement Checkbox = driver.findElement(By.xpath('//span[text()="Chip Attributes"]//preceding-sibling::div'))

    'Delay'
    WebUI.delay(2)

    if (Checkbox.displayed) {
        'Click'
        Checkbox.click()

        'Mark pass'
        KeywordUtil.logInfo('Passed')
    } else {
        'Mark fail'
        KeywordUtil.markFailed('Failed')
    }
}
catch (Exception e) {
    'Mark fail'
    KeywordUtil.markFailed('Cannot find object')
} 

'Delay'
WebUI.delay(10)

