import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.waitForPageLoad(30)

'Highlights Wafer Fab Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/WaferFabCB'))

not_run: WebUI.delay(2)

'Checks Wafer Fab Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/WaferFabCB'))

WebUI.delay(2)

'Highlights Probe Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/ProbeCB'))

not_run: WebUI.delay(2)

'Checks Probe Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/ProbeCB'))

WebUI.delay(2)

'Highlights Backside Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/BacksideCB'))

not_run: WebUI.delay(2)

'Checks Backside Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/BacksideCB'))

WebUI.delay(2)

'Highlights Bump Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/BumpCB'))

not_run: WebUI.delay(2)

'Checks Bump Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/BumpCB'))

WebUI.delay(2)

'Highlights Assembly Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/AssemblyCB'))

not_run: WebUI.delay(2)

'Checks Assembly Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/AssemblyCB'))

WebUI.delay(2)

'Highlights Final Test Checkbox.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Checkboxes/SourcingPlanCheckboxes/FinalTestCB'))

not_run: WebUI.delay(2)

'Checks Final Test Checkbox.'
WebUI.check(findTestObject('Checkboxes/SourcingPlanCheckboxes/FinalTestCB'))

WebUI.delay(5)

