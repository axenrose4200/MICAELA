import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.By as By
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebDriver driver = DriverFactory.getWebDriver()

boolean compare = false

'Package Designator, checks the checkboxes'
WebElement YAB = driver.findElement(By.xpath('//div[contains(text(), \'YAB\')]'))

YAB.click()

boolean YABr = YAB.isEnabled()

WebElement YAF = driver.findElement(By.xpath('//div[contains(text(), \'YAF\')]'))

YAF.click()

boolean YAFr = YAF.isEnabled()

WebElement YAH = driver.findElement(By.xpath('//div[contains(text(), \'YAH\')]'))

YAH.click()

boolean YAHr = YAH.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((YABr && YAFr) && YAHr) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Package Identifier, checks the checkboxes'
WebElement a = driver.findElement(By.xpath('//div[contains(text(), \'-0001\')]'))

a.click()

boolean ar = a.isEnabled()

WebElement b = driver.findElement(By.xpath('//div[contains(text(), \'-01\')]'))

b.click()

boolean br = b.isEnabled()

WebElement non = driver.findElement(By.xpath('//div[contains(text(), \'NONE \')]'))

non.click()

boolean nonr = non.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((ar && br) && nonr) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Package Designator Status, checks the checkboxes'
WebElement status1 = driver.findElement(By.xpath('//div[contains(text(), \'Development \')]'))

status1.click()

boolean status1r = status1.isEnabled()

WebElement status2 = driver.findElement(By.xpath('//div[contains(text(), \'Not Recommended \')]'))

status2.click()

boolean status2r = status2.isEnabled()

WebElement status3 = driver.findElement(By.xpath('//div[contains(text(), \'Reserved \')]'))

status3.click()

boolean status3r = status3.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((status1r && status2r) && status3r) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'WCSP Preference code, checks the checkboxes'
WebElement act = driver.findElement(By.xpath('//div[contains(text(), \'Active \')]'))

act.click()

boolean actr = act.isEnabled()

WebElement cal = driver.findElement(By.xpath('//div[contains(text(), \'Calculated \')]'))

cal.click()

boolean calr = cal.isEnabled()

WebElement res = driver.findElement(By.xpath('//div[contains(text(), \'Restricted \')]'))

res.click()

boolean resr = res.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((actr && calr) && resr) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Pitch (mm), checks the checkboxes'
WebElement a1 = driver.findElement(By.xpath('//div[contains(text(), \'.35 \')]'))

a1.click()

boolean a1r = a1.isEnabled()

WebElement b1 = driver.findElement(By.xpath('//div[contains(text(), \'.4 \')]'))

b1.click()

boolean b1r = b1.isEnabled()

WebElement c1 = driver.findElement(By.xpath('//div[contains(text(), \'.5 \')]'))

c1.click()

boolean c1r = c1.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((a1r && b1r) && c1r) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Bump tech, checks the checkboxes'
WebElement bump1 = driver.findElement(By.xpath('//div[contains(text(), \'BOP-FCI\')]'))

bump1.click()

boolean bump1r = bump1.isEnabled()

WebElement bump2 = driver.findElement(By.xpath('//div[contains(text(), \'BOP-S \')]'))

bump2.click()

boolean bump2r = bump2.isEnabled()

WebElement bump3 = driver.findElement(By.xpath('//div[contains(text(), \'BOPCOA_BCB\')]'))

bump3.click()

boolean bump3r = bump3.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((bump1r && bump2r) && bump3r) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Saw technique, checks the checkboxes'
WebElement saw1 = driver.findElement(By.xpath('//div[contains(text(), \'Laser\')]'))

saw1.click()

boolean saw1r = saw1.isEnabled()

WebElement saw2 = driver.findElement(By.xpath('//div[contains(text(), \'Mechanical\')]'))

saw2.click()

boolean saw2r = saw2.isEnabled()

'Checks if it is a multiple selection checkbox'
if (saw1 && saw2) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Mettop Scribe Seal, checks the checkboxes'
WebElement met1 = driver.findElement(By.xpath('(//div[contains(text(), \'No\')])[2]'))

met1.click()

boolean met1r = met1.isEnabled()

WebElement met2 = driver.findElement(By.xpath('//div[contains(text(), \'Yes \')]'))

met2.click()

boolean met2r = met2.isEnabled()

'Checks if it is a multiple selection checkbox'
if (met1 && met2) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Ball diameter, checks the checkboxes'
WebElement ball1 = driver.findElement(By.xpath('(//div[contains(text(), \'150 \')])[1]'))

ball1.click()

boolean ball1r = ball1.isEnabled()

WebElement ball2 = driver.findElement(By.xpath('(//div[contains(text(), \'170\')])[1]'))

ball2.click()

boolean ball2r = ball2.isEnabled()

WebElement ball3 = driver.findElement(By.xpath('//div[contains(text(), \'180 \')]'))

ball3.click()

boolean ball3r = ball3.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((ball1r && ball2r) && ball3r) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'ubm diameter, checks the checkboxes'
WebElement ubm1 = driver.findElement(By.xpath('//div[contains(text(), \'125 \')]'))

ubm1.click()

boolean ubm1r = ubm1.isEnabled()

WebElement ubm2 = driver.findElement(By.xpath('(//div[contains(text(), \'150\')])[2]'))

ubm2.click()

boolean ubm2r = ubm2.isEnabled()

WebElement ubm3 = driver.findElement(By.xpath('(//div[contains(text(), \'170 \')])[2]'))

ubm3.click()

boolean ubm3r = ubm3.isEnabled()

'Checks if it is a multiple selection checkbox'
if ((ubm1r && ubm2r) && ubm3r) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All1 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[1]'))

boolean All1r = All1.isSelected()

'Verify if all is deselected\r\n'
if (All1r == compare) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All2 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[2]'))

boolean All2r = All2.isSelected()

'Verify if all is deselected\r\n\r\n'
if (All2r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All3 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[3]'))

boolean All3r = All3.isSelected()

'Verify if all is deselected\r\n\r\n'
if (All3r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All4 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[4]'))

boolean All4r = All4.isSelected()

'Verify if all is deselected\r\n'
if (All4r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All5 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[5]'))

boolean All5r = All5.isSelected()

'Verify if all is deselected\r\n'
if (All5r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All6 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[6]'))

boolean All6r = All6.isSelected()

'Verify if all is deselected\r\n'
if (All6r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All7 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[7]'))

boolean All7r = All7.isSelected()

'Verify if all is deselected\r\n'
if (All7r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All8 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[8]'))

boolean All8r = All8.isSelected()

'Verify if all is deselected\r\n'
if (All8r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All9 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[9]'))

boolean All9r = All9.isSelected()

'Verify if all is deselected\r\n'
if (All9r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All10 = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[10]'))

boolean All10r = All10.isSelected()

'Verify if all is deselected\r\n'
if (All10r == false) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.delay(5)

