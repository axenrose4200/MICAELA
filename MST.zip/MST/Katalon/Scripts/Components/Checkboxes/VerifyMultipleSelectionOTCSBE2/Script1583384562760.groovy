import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.testng.Assert as Assert
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebDriver driver = DriverFactory.getWebDriver()

boolean compare = false

'Package Group, checks the checkboxes'
WebElement CMPS = driver.findElement(By.xpath('//div[contains(text(), \'AMPS-CMPS\')]//preceding-sibling::mat-pseudo-checkbox'))

CMPS.click()

boolean CMPSr = CMPS.isEnabled()

WebElement GPAMPS = driver.findElement(By.xpath('//div[contains(text(), \'AMPS-GPAMPS\')]//preceding-sibling::mat-pseudo-checkbox'))

GPAMPS.click()

boolean GPAMPSr = GPAMPS.isEnabled()

WebElement HSAMPS = driver.findElement(By.xpath('//div[contains(text(), \'AMPS-HSAMPS\')]//preceding-sibling::mat-pseudo-checkbox'))

HSAMPS.click()

boolean HSAMPSr = HSAMPS.isEnabled()

if ((CMPSr && GPAMPSr) && HSAMPSr) {
    KeywordUtil.markPassed('Multiple Selections are enabled')
} else {
    KeywordUtil.markFailed('Failed')
}

WebElement All = driver.findElement(By.xpath('(//div[contains(text(), \'All\')])[1]//preceding-sibling::mat-pseudo-checkbox'))

boolean Allr = All.isSelected()

'Verify if all is deselected\r\n'
if (Allr == false) {
    KeywordUtil.markPassed('All is deselected')
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.delay(5)

