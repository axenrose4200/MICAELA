import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebDriver driver = DriverFactory.getWebDriver()

'Navigates to Shared URL'
WebUI.navigateToUrl(sharedURL)

'page to load'
WebUI.delay(5)

WebElement date1 = driver.findElement(By.xpath('//*[contains(text(), "Last Saved")]'))

date1t = date1.getText()

//def date1 = WebUI.getText(findTestObject('Page_Manufacturing Selection Tool/Text Area/DateForPackageSearch1'))
'clicks save button\r\n'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Sourcing_Button_DropDown'))

WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Button/Save As New_DropDown'), 0)

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save As New_DropDown'))

'Verify if naming box is present'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Text Area/RenameDialog'), 0)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Text Area/Offset Click'))

WebUI.setText(findTestObject('Page_Manufacturing Selection Tool/Text Area/Draft Naming Box'), 'Draft Rename ')

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/SaveSourcingDraft'))

WebUI.delay(5)

WebUI.verifyTextPresent('Draft Rename', false)

'Verifies that there is only Save As New button\r\n'
if (WebUI.verifyTextPresent('Draft Rename', false)) {
    KeywordUtil.markPassed('Passed')

    'Navigates to Shared URL'
    WebUI.navigateToUrl(sharedURL)
} else {
    KeywordUtil.markFailed('Failed')
}

'Navigates to Shared URL'
WebUI.navigateToUrl(sharedURL)

WebUI.delay(5)

WebElement date2 = driver.findElement(By.xpath('//*[contains(text(), "Last Saved:")]'))

date2t = date2.getText()

//def date2 = WebUI.getText(findTestObject('Page_Manufacturing Selection Tool/Text Area/DateForPackageSearch2'))
'Verify that there are no modifications'
if (WebUI.verifyEqual(date1t, date2t)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.delay(0)

