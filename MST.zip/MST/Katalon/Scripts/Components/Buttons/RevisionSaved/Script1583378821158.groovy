import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.testng.Assert as Assert
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebDriver driver = DriverFactory.getWebDriver()
try{
WebElement item = driver.findElement(By.xpath('(//td[contains(text(), "Test Save")])[1]'))

item.click()

//revision1 values
WebElement ctech = driver.findElement(By.xpath('//strong[contains(text(), "TSMC-WF6")]'))

text1 = ctech.getAttribute('value')

println(text1)

//WebElement lprtech = driver.findElement(By.xpath('//strong[contains(text(), "CD-PR")]'))
//
//text2 = lprtech.getAttribute('value')
//
//WebElement prtech = driver.findElement(By.xpath('//strong[contains(text(), "SCLAB")]'))
//
//text3 = prtech.getAttribute('value')
//
//WebElement scribe = driver.findElement(By.xpath('//strong[contains(text(), "NOSOURCE")]'))
//
//text4 = scribe.getAttribute('value')

//WebElement primary = driver.findElement(By.xpath('//input[@placeholder="Primary Factory"]'))
//
//text5 = primary.getAttribute('value')

WebUI.delay(5)

//click to revision 0
WebElement revisionpage = driver.findElement(By.xpath('(//mat-icon[@class="mat-icon notranslate material-icons mat-icon-no-color"])[5]'))

revisionpage.click()

WebElement pastrevision = driver.findElement(By.xpath('//strong[contains(text(), "Revision 0")]'))

pastrevision.click()

	WebElement ctech1 = driver.findElement(By.xpath('(//span[contains(text(), " LRPTECH:")])[1]'))
	
ext1 = ctech.getText()
	
println(ext1)
}
catch(Exception e){
	System.out.println("The data has been saved")
	'verify that past revisions are read only'
	if(WebUI.verifyTextPresent('Past revisions are read only', false)){
		KeywordUtil.markPassed("Passed")
	}
	else{
		KeywordUtil.markFailed("Failed")
	}
}



//WebElement lprtech1 = driver.findElement(By.xpath('(//span[contains(text(), " Temperature:")])[1]'))
//
//ext2 = lprtech.getText()
//
//
//Assert.assertNotEquals(text1, ext1)
//
//Assert.assertNotEquals(text2, ext2)
//
//Assert.assertNotEquals(text3, ext3)
//
//Assert.assertNotEquals(text4, ext4)
//
////Assert.assertNotEquals(text5, ext5)





