import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Waits for 30 seconds for page load'
WebUI.waitForPageLoad(30)

'Verifies if Automotive button exists.'
if (WebUI.waitForElementPresent(findTestObject('Button/Burn-inDisable'), 30)) {
    'Highlights the clear button'
    CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/Burn-inDisable'))

    'Marks the verification point as "Passed".'
    KeywordUtil.markPassed('Button exists.')
} else {
    'Marks the verification point as "Failed"'
    KeywordUtil.markFailed('Button is not in default or does not exist.')
}

'Clicks the Inserion 3 button'
WebUI.click(findTestObject('Button/Burn-inDisable'))

'Delays the next step for 2 seconds'
WebUI.delay(2)

