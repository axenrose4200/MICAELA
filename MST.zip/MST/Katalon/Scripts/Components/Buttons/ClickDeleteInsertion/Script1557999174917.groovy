import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

'Waits for 30 seconds for page load'
WebUI.waitForPageLoad(30)

'Verifies if the copy button exists.'
if (WebUI.verifyElementPresent(findTestObject('Button/ClearButton/DeleteInsertion'), 30)) {
    'Highlights the copy button'
    CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/ClearButton/DeleteInsertion'))

    'Clicks the copy button'
    WebUI.click(findTestObject('Button/ClearButton/DeleteInsertion'))

    'Marks the verification point as "Passed".'
    KeywordUtil.markPassed('Copy Button exists.')
} else {
    'Marks the verification point as "Failed"'
    KeywordUtil.markFailed('Copy Button does not exist!')
}

'Delays the next step for 2 seconds'
WebUI.delay(2)

