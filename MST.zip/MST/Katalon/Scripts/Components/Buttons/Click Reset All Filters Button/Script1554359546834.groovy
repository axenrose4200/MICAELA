import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.comment('Wait for page load for 30 seconds.')

WebUI.waitForPageLoad(30)

WebUI.comment('Highlights Reset All Filters button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/ResetButtons/ResetAllFiltersButton'))

WebUI.comment('Clicks Reset All Filters button.')

WebUI.click(findTestObject('Button/ResetButtons/ResetAllFiltersButton'))

WebUI.comment('Delays next step for 5 seconds for page load.')

WebUI.delay(7)

