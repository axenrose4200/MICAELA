import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Waits 30 seconds for page load.'
WebUI.waitForPageLoad(30)

'Verify if Automotive Flag exists.'
if(WebUI.verifyElementPresent(findTestObject('Button/SourcingSelection/AutomotiveFlag'), 5))
{
	'Marks verification point as passed.'
	KeywordUtil.markPassed("Automotive Flag exists.")
}

else
{
	'Marks verification point as failed.'
	KeywordUtil.markFailed("Please check if Automotive Flag exists in this page.")
	
	'Takes Screenshot'
	WebUI.takeScreenshot()
}

'Enables Automotive Flag.'
WebUI.click(findTestObject('Button/SourcingSelection/AutomotiveFlag'))

'Verifies if Automation Flag is enabled.'
if(WebUI.verifyElementPresent(findTestObject('Button/SourcingSelection/AutomotiveFlagEnabled'), 5))
{
	'Marks verification point as passed.'
	KeywordUtil.markPassed("Automotive Flag was enabled.")
}

else
{
	'Marks verfication point as failed.'
	KeywordUtil.markFailed("Automotive Flag was not enabled.")
	
	'Takes screenshot'
	WebUI.takeScreenshot()
}