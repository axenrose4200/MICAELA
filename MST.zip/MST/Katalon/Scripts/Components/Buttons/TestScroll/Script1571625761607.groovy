import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Wait for page load'
WebUI.waitForPageLoad(30)

'Verify if element is present'
boolean bool = WebUI.waitForElementPresent(findTestObject('Test/field'), 10)

if(bool){
	
	'Mark as passed'
	KeywordUtil.markPassed("Object exists")
} else {
	'Mark as failed'
	KeywordUtil.markFailed('Object not found!')

}

