import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Waits for 30 seconds for page load'
WebUI.waitForPageLoad(30)

'Verifies if the copy button exists.'
if (WebUI.verifyElementPresent(findTestObject('Button/CopyButton/FinalTestInsertion2Copy'), 30)) {
    'Highlights the copy button'
    CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/CopyButton/FinalTestInsertion2Copy'))

    'Marks the verification point as "Passed".'
    KeywordUtil.markPassed('Copy Button exists.')
} else {
    'Marks the verification point as "Failed"'
    KeywordUtil.markFailed('Copy Button does not exist!')
}
//CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/CopyButton/ProbeInsertion1Copy'))
//
//WebUI.verifyElementPresent(findTestObject('Button/CopyButton/ProbeInsertion1Copy'), 30)

'Clicks the copy button'
WebUI.click(findTestObject('Button/CopyButton/FinalTestInsertion2Copy'))

'Delays the next step for 2 seconds'
WebUI.delay(2)

