import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.testng.Assert as Assert
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebDriver driver = DriverFactory.getWebDriver()

WebElement item = driver.findElement(By.xpath('//td[contains(text(), "TestSave Sourcing Selection Search")]'))

item.click()

WebUI.delay(5)

WebElement waferfabNav = driver.findElement(By.xpath('//div[text() = "Wafer Fab"]'))

waferfabNav.click()

WebUI.delay(5)

WebUI.callTestCase(findTestCase('Components/Filters/WaferFabFiltersMultipleValue/FillCTECHFilter'), [('param_value1') : ' LBC4 '], 
    FailureHandling.STOP_ON_FAILURE)

//WebUI.callTestCase(findTestCase('Components/Filters/ProbeFilters/Fill Probe Test Temperature Filters'), [('param_value1') : ' Room '], 
//    FailureHandling.STOP_ON_FAILURE)

WebElement sourcingNav = driver.findElement(By.xpath('//div[text() = "Sourcing Plan"]'))

sourcingNav.click()

'Click save drop down\r\n'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Sourcing_Button_DropDown'))

'Click to save revision\r\n\r\n'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Reivision_Draft'))

'verify if the dialog box is present'
if (WebUI.verifyTextPresent('MST will run Overall Review assessment before saving.', false)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Verify if the save button is present'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Draft_Name'), 0)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

'Veify if the dont save button is present'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Button/DontSave_Draft_Name'), 0)) {
    KeywordUtil.markPassed('Passed')
	'Clicks Save to Save the draft'
	WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Draft_Name'))
} else {
    KeywordUtil.markFailed('Failed')
}


//'Saves the file'
//WebElement saveFile = driver.findElement(By.xpath('//button[@class="mat-raised-button mat-primary"]'))
//saveFile.click()

WebUI.delay(5)





