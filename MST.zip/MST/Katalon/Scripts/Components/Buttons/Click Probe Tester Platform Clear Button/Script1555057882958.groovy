import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Waits for 30 seconds for page load'
WebUI.waitForPageLoad(30)

'Verifies if the clear button exists.'
if(WebUI.waitForElementPresent(findTestObject('Button/ClearButton/ProbeTesterPlatformClearButton'), 30)){
	
	'Highlights the clear button'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Button/ClearButton/ProbeTesterPlatformClearButton'))
	
	'Marks the verification point as "Passed".'
	KeywordUtil.markPassed("Clear Button exists.")
} else {
	'Marks the verification point as "Failed"'
	KeywordUtil.markFailed("Clear Button does not exist!")

}

'Clicks the clear button'
WebUI.click(findTestObject('Button/ClearButton/ProbeTesterPlatformClearButton'))

'Delays the next step for 2 seconds'
WebUI.delay(2)


