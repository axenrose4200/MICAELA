import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

'Navigates to Shared URL'
WebUI.navigateToUrl('https://mstweb-dev.itg.ti.com/mst/packaging/wirebond?id=170')

'clicks save button\r\n'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Sourcing_Button_DropDown'))

WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Button/Save As New_DropDown'), 0)

'Verifies that there is only Save As New button\r\n'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Button/Save As New_DropDown'), 0)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.delay(5)

