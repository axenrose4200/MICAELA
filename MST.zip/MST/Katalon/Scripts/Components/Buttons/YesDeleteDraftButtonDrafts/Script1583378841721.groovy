import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebDriver driver = DriverFactory.getWebDriver()

'Counts the rows before deletion'
List<WebElement> beforeDelete = driver.findElements(By.xpath('//tr[@class="mat-row ng-star-inserted"]'))

int beforeDeleteResult = beforeDelete.size()

println(beforeDeleteResult)

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Text Area/OffsetClickBody'))

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/DeleteMySavedDrafts'))

WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Text Area/DialogBoxDeletion'), 0)

'Verifies dialog box present'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Text Area/DialogBoxDeletion'), 0)) {
    KeywordUtil.markPassed('Dialog Box Present')

    WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Text Area/Offset Click'))
} else {
    KeywordUtil.markFailed('Failed')
}

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Text Area/Offset Click'))

'Clicks on delete button'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Yes_Delete'))

List<WebElement> afterDelete = driver.findElements(By.xpath('//tr[@class="mat-row ng-star-inserted"]'))

int afterDeleteResult = afterDelete.size()

'Verifies that user can mass delete drafts'
if (beforeDeleteResult > afterDeleteResult) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

