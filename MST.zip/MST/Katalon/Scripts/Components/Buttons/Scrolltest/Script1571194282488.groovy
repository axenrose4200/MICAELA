import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.WebDriverWait

import com.kms.katalon.core.webui.driver.DriverFactory as DF
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Initialization'
WebDriver driver = DF.getWebDriver()
driver.switchTo().defaultContent()
WebElement element = driver.findElement(By.xpath('//iframe[@style= "border: 0px; margin: 0px; padding: 0px; width: 100%; height: 100%;"]'))
driver.switchTo().frame(element)

//WebElement scroll = driver.findElement(By.xpath('//div[text()="MST Min Step Y (mm)"]'))

//WebElement scroll = driver.findElement(By.xpath('(//div[@class="ScrollbarButton sf-element sf-element-scroll-bar-button sfpc-right"])[3]'))
//((JavascriptExecutor)driver).executeScript('window.scrollBy(20000,0)');
//((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", scroll)

Actions action = new Actions(driver);
WebElement we = driver.findElement(By.xpath('//div[@class="sf-element sf-element-visual-content sfc-table"]'))
//WebElement we = driver.findElement(By.xpath('//div[@id="id86"]'))

WebUI.delay(2)
action.moveToElement(we).moveToElement(driver.findElement(By.xpath('(//div[@class="HorizontalScrollbarContainer sf-element sf-element-scroll-bar sfpc-bottom"]//div[@class="ScrollbarHandle sf-element sf-element-scroll-bar-handle"])[14]'))).click().build().perform()
WebUI.delay(2)

//WebUI.mouseOver(findTestObject('Details'))
//WebElement scroll =  driver.findElement(By.xpath('(//div[@class="HorizontalScrollbarContainer sf-element sf-element-scroll-bar sfpc-bottom"]//div[@class="ScrollbarHandle sf-element sf-element-scroll-bar-handle"])[11]'))
//action.dragAndDropBy(scroll, 500, 0)


WebElement scrollbutton = driver.findElement(By.xpath('(//div[@class="ScrollbarButton sf-element sf-element-scroll-bar-button sfpc-right"])[14]'))

for(int s = 0; s<=6 ; s++){
	
//	WebDriverWait wait = new WebDriverWait(scrollbutton, 10)
//	wait.until(
//		ExpectedConditions.visibilityOfElementLocated(By.xpath('(//div[@class="ScrollbarButton sf-element sf-element-scroll-bar-button sfpc-right"])[11]')))
//		scrollbutton.findElement(By.xpath('(//div[@class="ScrollbarButton sf-element sf-element-scroll-bar-button sfpc-right"])[11]'))
		
scrollbutton.click()
WebUI.delay(1)
}
driver.switchTo().defaultContent()

