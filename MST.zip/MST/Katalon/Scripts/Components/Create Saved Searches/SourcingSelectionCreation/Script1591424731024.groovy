import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.testng.Assert as Assert
import org.testng.asserts.Assertion as Assertion
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import org.apache.http.util.Asserts as Asserts
import org.junit.After as After
import org.openqa.selenium.By as By
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor

WebDriver driver = DriverFactory.getWebDriver()
try{
'Navigates to Sourcing Selection to create a saved search and checks if the navigation is present'
WebElement sourceSelection = driver.findElement(By.xpath('//a[@href="/mst/sourcing"]'))
sourceSelection.click()
'Delays for 5 seconds'
WebUI.delay(5)	
'input 1 on max4 field'
WebElement max4 = driver.findElement(By.xpath('//input[@placeholder="Max 4-Qtr NUBs (k)"]'))
max4.sendKeys('1')
'input 1 on chips field'
WebElement chips = driver.findElement(By.xpath('//input[@placeholder="Chips per Wafer (CPW)"]'))
chips.sendKeys('1')
'Delays for 5 seconds'
WebUI.delay(5)
'clicks on save button and checks if the element is present'
WebElement save = driver.findElement(By.xpath('//button[@class="primary mat-raised-button"]'))
save.click()
'clicks on save as button and checks if the element is present'
WebElement saveAs = driver.findElement(By.xpath('//div[@class="mat-menu-content"]'))
saveAs.click()
'Clicks on the save field to be able to input a name to save'
WebElement randomClick = driver.findElement(By.xpath('//h1[@class="mat-dialog-title"]'))
randomClick.click()
'Inputs on a text field to name the save search'
WebElement name = driver.findElement(By.xpath('//input[@class="mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-invalid ng-touched"]'))
name.sendKeys('TestSave Sourcing Selection Search')
'Saves the file'
WebElement saveFile = driver.findElement(By.xpath('//button[@class="mat-raised-button mat-primary"]'))
saveFile.click()

}
catch (def Exception) {
	KeywordUtil.markFailed('Object not found')
}
