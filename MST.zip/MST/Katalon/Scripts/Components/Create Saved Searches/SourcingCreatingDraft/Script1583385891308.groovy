import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Clicks save button\r\n'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Sourcing_Button_DropDown'))

'Clicks Save As button'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save As New_DropDown'))

WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Text Area/Offset Click'))

'Names the draft'
WebUI.setText(findTestObject('Page_Manufacturing Selection Tool/Text Area/Draft Naming Box(1)'), 'Test Save')

'Clicks Save to Save the draft'
WebUI.click(findTestObject('Page_Manufacturing Selection Tool/Button/Save_Draft_Name'))

'Verifies the draft is saved'
if (WebUI.verifyTextPresent('Saved', false)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

