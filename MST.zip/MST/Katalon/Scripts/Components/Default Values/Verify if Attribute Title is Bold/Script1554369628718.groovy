import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.comment('Wait for page load for 30 seconds.')

WebUI.waitForPageLoad(30)

WebUI.comment('Highlights LRPTECH attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/LRPTECHAttribute'))

WebUI.comment('Verifies if LRPTECH attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/LRPTECHAttribute'), 30)) {
    KeywordUtil.markPassed('LRPTECH attribute title is bold.')
} else {
    KeywordUtil.markFailed('LRPTECH attribute title is not bold.')
}

WebUI.comment('Highlights Probe Test Temparature attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/ProbeTestTemperatureAttribute'))

WebUI.comment('Verifies if Probe Test Temperature title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/ProbeTestTemperatureAttribute'), 
    30)) {
    KeywordUtil.markPassed('Probe Test Temperature attribute title is bold.')
} else {
    KeywordUtil.markFailed('Probe Test Temperature attribute title is not bold.')
}

WebUI.comment('Highlights Probe Test Platform attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/PROBETesterPlatformAttribute'))

WebUI.comment('Verifies if Probe Test Platform title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/PROBETesterPlatformAttribute'), 30)) {
    KeywordUtil.markPassed('Probe Test Platform attribute title is bold.')
} else {
    KeywordUtil.markFailed('Probe Test Platform attribute title is not bold.')
}

WebUI.comment('Highlights Backside Bump Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/BacksideBumpType'))

WebUI.comment('Verifies Backside Bump Type attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/BacksideBumpType'), 30)) {
    KeywordUtil.markPassed('Backside Bump Type attribute title is bold.')
} else {
    KeywordUtil.markFailed('Backside Bump Type attribute title is not bold.')
}

WebUI.comment('Highlights Bump Bump Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/BumpBumpType'))

WebUI.comment('Verifies if Bump Bump Type attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/BumpBumpType'), 30)) {
    KeywordUtil.markPassed('Bump Bump Type attribute title is bold.')
} else {
    KeywordUtil.markFailed('Bump Bump Type attribute title is not bold.')
}

WebUI.comment('Highlights Assembly Package Designator attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageDesignator'))

WebUI.comment('Verifies if Assembly Package Deisgnator title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageDesignator'), 30)) {
    KeywordUtil.markPassed('Assembly Package Deisgnator attribute title is bold.')
} else {
    KeywordUtil.markFailed('Assembly Package Deisgnator attribute title is not bold.')
}

WebUI.comment('Highlights Assembly Pins attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPins'))

WebUI.comment('Verifies if Assembly Pins attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPins'), 30)) {
    KeywordUtil.markPassed('Assembly Pins attribute title is bold.')
} else {
    KeywordUtil.markFailed('Assembly Pins attribute title is not bold.')
}

WebUI.comment('Highlights Assembly Package Group DCM attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageGroupDCM'))

WebUI.comment('Verifies if Assembly Package Group DCM attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageGroupDCM'), 30)) {
    KeywordUtil.markPassed('Assembly Package Group DCM attribute title is bold.')
} else {
    KeywordUtil.markFailed('Assembly Package Group DCM attribute title is not bold.')
}

WebUI.comment('Highlights Final Test Test Temperature attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestTemperature'))

WebUI.comment('Verifies if Final Test Temperature attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestTemperature'), 30)) {
    KeywordUtil.markPassed('Final Test Test Temperature attribute title is bold.')
} else {
    KeywordUtil.markFailed('Final Test Test Temperature attribute title is not bold.')
}

WebUI.comment('Highlights Primary Handler Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestPrimaryHandlerType'))

WebUI.comment('Verifies if Primary Handler Type attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestPrimaryHandlerType'), 30)) {
    KeywordUtil.markPassed('Primary Handler Type attribute title is bold.')
} else {
    KeywordUtil.markFailed('Primary Handler Type attribute title is not bold.')
}

WebUI.comment('Highlights Final Test Tester Platform attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FINALTESTTesterPlatform'))

WebUI.comment('Verifies if Final Tester Platform attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FINALTESTTesterPlatform'), 30)) {
    KeywordUtil.markPassed('Final Tester Platform attribute title is bold.')
} else {
    KeywordUtil.markFailed('Final Tester Platform attribute title is not bold.')
}

WebUI.comment('Highlights Final Test Secondary Handler Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestSecondaryHandlerType'))

WebUI.comment('Verifies if Final Test Secondary Handler Type attribute title is bold.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestSecondaryHandlerType'), 
    30)) {
    KeywordUtil.markPassed('Final Test Secondary Handler Type attribute title is bold.')
} else {
    KeywordUtil.markFailed('Final Test Secondary Handler Type attribute title is not bold.')
}

WebUI.comment('Delays next step for 5 seconds for page load.')

WebUI.delay(5)

