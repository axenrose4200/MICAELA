import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Checks if the element is not present'
WebUI.verifyElementNotPresent(findTestObject('Saved Draft Values/Packaging Columns/Revision Heading'), 0)

'Checks if the user dont have a view of Revision'
WebUI.verifyElementNotVisibleInViewport(findTestObject('Saved Draft Values/Packaging Columns/Revision Heading'), 0)

'Verifies the element is hidden'
if (WebUI.verifyElementNotPresent(findTestObject('Saved Draft Values/Packaging Columns/Revision Heading'), 0)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

