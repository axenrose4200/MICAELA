import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.comment('Waits 30 seconds for page load.')

WebUI.waitForPageLoad(30)

WebUI.comment('Highlights the expand button.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand1'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand1'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand1'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights LRPTECH attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/LRPTECHAttribute'))

WebUI.comment('Verifies if LRPTECH attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/LRPTECHAttribute'), 30)) {
    KeywordUtil.markPassed('LRPTECH attribute is present.')
} else {
    KeywordUtil.markFailed('LRPTECH attribute is not present.')
}

WebUI.comment('Highlights the expand button.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand2'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand2'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand2'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights Probe Test Temparature attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/ProbeTestTemperatureAttribute'))

WebUI.comment('Verifies if Probe Test Temperature is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/ProbeTestTemperatureAttribute'), 
    30)) {
    KeywordUtil.markPassed('Probe Test Temperature attribute is present.')
} else {
    KeywordUtil.markFailed('Probe Test Temperature attribute is not present.')
}

WebUI.comment('Highlights Probe Test Platform attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/PROBETesterPlatformAttribute'))

WebUI.comment('Verifies if Probe Test Platform is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/PROBETesterPlatformAttribute'), 30)) {
    KeywordUtil.markPassed('Probe Test Platform attribute is present.')
} else {
    KeywordUtil.markFailed('Probe Test Platform attribute is not present.')
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand3'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand3'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand3'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights Backside Bump Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/BacksideBumpType'))

WebUI.comment('Verifies Backside Bump Type attribute.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/BacksideBumpType'), 30)) {
    KeywordUtil.markPassed('Backside Bump Type attribute is present.')
} else {
    KeywordUtil.markFailed('Backside Bump Type attribute is not present.')
}

WebUI.comment('Highlights the expand button.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand4'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand4'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand4'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights Bump Bump Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/BumpBumpType'))

WebUI.comment('Verifies if Bump Bump Type attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/BumpBumpType'), 30)) {
    KeywordUtil.markPassed('Bump Bump Type attribute is present.')
} else {
    KeywordUtil.markFailed('Bump Bump Type attribute is not present.')
}

WebUI.comment('Highlights the expand button.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand5'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand5'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand5'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights Assembly Package Designator attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageDesignator'))

WebUI.comment('Verifies if Assembly Package Deisgnator is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageDesignator'), 30)) {
    KeywordUtil.markPassed('Assembly Package Deisgnator attribute is present.')
} else {
    KeywordUtil.markFailed('Assembly Package Deisgnator attribute is not present.')
}

WebUI.comment('Highlights Assembly Pins attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPins'))

WebUI.comment('Verifies if Assembly Pins attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPins'), 30)) {
    KeywordUtil.markPassed('Assembly Pins attribute is present.')
} else {
    KeywordUtil.markFailed('Assembly Pins attribute is not present.')
}

WebUI.comment('Highlights Assembly Package Group DCM attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageGroupDCM'))

WebUI.comment('Verifies if Assembly Package Group DCM attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/AssemblyPackageGroupDCM'), 30)) {
    KeywordUtil.markPassed('Assembly Package Group DCM attribute is present.')
} else {
    KeywordUtil.markFailed('Assembly Package Group DCM attribute is not present.')
}

WebUI.comment('Highlights the expand button.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand6'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand6'), 30)) {
    KeywordUtil.markPassed('Attribute is expanded.')

    WebUI.click(findTestObject('Default Values/Sourcing Plan/Expand/Expand6'))
} else {
    KeywordUtil.markFailed('Attribute is not expanded.')
}

WebUI.comment('Highlights Final Test Test Temperature attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestTemperature'))

WebUI.comment('Verifies if Final Test Temperature attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestTemperature'), 30)) {
    KeywordUtil.markPassed('Final Test Test Temperature attribute is present.')
} else {
    KeywordUtil.markFailed('Final Test Test Temperature attribute is not present.')
}

WebUI.comment('Highlights Primary Handler Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestPrimaryHandlerType'))

WebUI.comment('Verifies if Primary Handler Type attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestPrimaryHandlerType'), 30)) {
    KeywordUtil.markPassed('Primary Handler Type attribute is present.')
} else {
    KeywordUtil.markFailed('Primary Handler Type attribute is not present.')
}

WebUI.comment('Highlights Final Test Tester Platform attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FINALTESTTesterPlatform'))

WebUI.comment('Verifies if Final Tester Platform attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FINALTESTTesterPlatform'), 30)) {
    KeywordUtil.markPassed('Final Tester Platform attribute is present.')
} else {
    KeywordUtil.markFailed('Final Tester Platform attribute is not present.')
}

WebUI.comment('Highlights Final Test Secondary Handler Type attribute.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestSecondaryHandlerType'))

WebUI.comment('Verifies if Final Test Secondary Handler Type attribute is present.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Attributes/FinalTestSecondaryHandlerType'), 
    30)) {
    KeywordUtil.markPassed('Final Test Secondary Handler Type attribute is present.')
} else {
    KeywordUtil.markFailed('Final Test Secondary Handler Type attribute is not present.')
}

WebUI.comment('Delays next step for 5 seconds for page load.')

WebUI.delay(5)

