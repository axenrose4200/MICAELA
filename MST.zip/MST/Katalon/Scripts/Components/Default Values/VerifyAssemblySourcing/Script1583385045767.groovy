import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'Verify that the element is present'
if(WebUI.verifyElementPresent(findTestObject('Default Values/WCSP.assemblySourcing'), 0)){
	KeywordUtil.markPassed("Passed")
}
else{
	KeywordUtil.markFailed("Failed")
}
