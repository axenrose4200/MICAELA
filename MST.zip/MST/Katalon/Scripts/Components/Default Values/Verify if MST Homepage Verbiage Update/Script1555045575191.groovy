import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Waits for 30 seconds page load.'
WebUI.waitForPageLoad(30)

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel1'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel1'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel2'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel2'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel3'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel3'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel4'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel4'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel5'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel5'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel6'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel6'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel7'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel7'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel8'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel8'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel9'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel9'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel10'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel10'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel11'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel11'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Verifies if the label is present.'
if(WebUI.verifyElementPresent(findTestObject('Default Values/Home/MSTLabel12'), 30)){
	'Highlights the label.'
	CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Home/MSTLabel12'))
	'Marks the verification point as passed'
	KeywordUtil.markPassed("Homepage label exists.")
} else {
	'Marks the verification point as failed'
	KeywordUtil.markFailed("Homepage label does not exist.")
	'Takes a screenshot.'
	WebUI.takeScreenshot()
}

'Delays next step for 5 seconds.'
WebUI.delay(5)