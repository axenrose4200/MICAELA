import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DF
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.JavascriptExecutor

'Initialization'
WebDriver driver = DF.getWebDriver()
driver.switchTo().defaultContent()
WebElement element = driver.findElement(By.xpath('//iframe[@style= "border: 0px; margin: 0px; padding: 0px; width: 100%; height: 100%;"]'))
driver.switchTo().frame(element)

WebElement AssemblySite = driver.findElement(By.xpath('//strong[text()="Assembly Site"]'))
((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AssemblySite)
String filter = AssemblySite.getText()


'Verify if Assembly Site Filter is present.'
if(AssemblySite.displayed){
	'Marks verification point as passed.'
	KeywordUtil.markPassed(filter + " filter exists.")
} else {
	'Marks verification point as failed.'
	KeywordUtil.markFailed(filter + ' filter is missing or has been modified.')
	'Take a screenshot'
	WebUI.takeScreenshot()
}


'Verify Default Value'
WebElement defValue = driver.findElement(By.xpath('//strong[text()="Assembly Site"]//parent::td//div[@class="sf-element-list-box-item sfpc-selected" and contains(text(),"All")]'))

if(defValue){
	'Mark as passed'
	KeywordUtil.markPassed('Default value passed.')
}
else
{
	'Marks as failed.'
	KeywordUtil.markFailed('Default value failed.')
}

driver.switchTo().defaultContent()