import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.driver.DriverFactory as DF
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


'Initialize'
WebDriver driver = DF.getWebDriver()
String attribute
List<String> attributelist = new ArrayList<String>()
ArrayList<String> arrlist = new ArrayList<>(Arrays.asList('Package Designator', 'Pin Count', 'Package Group',
							'Package Group DCM', 'Multi-Sourcing Threshold (k-NUB)', 'Assembly Max',
							'Multi-Sourcing Required', 'Scribe Width (μm)', 'Wettable Flank', 
							'Internal Roadmap Option', 'Qual Strategy Option', 'Future Strategy Option',
							'Automotive Development Option', 'Recovery Code', 'Sourcing Class', 
							'Automotive Sourcing Class', 'Description', 'Package-Pin'))
'Get Expanded Details'
try{
	
	WebElement TED = driver.findElement(By.xpath('//span[@class="ng-tns-c49-105 ng-star-inserted"]'))
	ted = TED.getText()
	int technology = Integer.parseInt(ted)
	println(technology)
	WebElement FED = driver.findElement(By.xpath('//span[@class="ng-tns-c49-107 ng-star-inserted"]'))
	fed = FED.getText()
	int factory = Integer.parseInt(fed)
	println(factory)
	
	'Get Attribute Text'
	for (int i = 1; i <= technology; i++){
		WebElement attr = driver.findElement(By.xpath('(//td[@class="mat-cell cdk-column-column mat-column-column ng-star-inserted"])['+ i +']'))
		attribute = attr.getText()
		attributelist.add(attribute)
		println(attribute)
	}
}
catch (Exception e){
	
	'Mark Fail'
	KeywordUtil.markFailed('Check expanded details xpath')
}

'Verifies if attributes are static'
	if(arrlist == attributelist){

		'Mark Pass'
		KeywordUtil.markPassed('Passed')
		println(arrlist)
		println(attributelist)
	}
	else
	{
		'Mark Fail'
		KeywordUtil.markFailed('Failed. Check if attribute order has been modified')
	}



