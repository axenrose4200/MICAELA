import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

'Checks if the element is present'
WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Default Values/SavedWirebondPackage'), 0)

'Verifies the element is present'
if (WebUI.verifyElementPresent(findTestObject('Page_Manufacturing Selection Tool/Default Values/SavedWirebondPackage'), 0)) {
    KeywordUtil.markPassed('Passed')
} else {
    KeywordUtil.markFailed('Failed')
}

