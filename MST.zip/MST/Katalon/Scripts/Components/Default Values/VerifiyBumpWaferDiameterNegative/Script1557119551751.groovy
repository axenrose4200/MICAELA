import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

'Waits 5 seconds for page load.\r\n'
WebUI.waitForPageLoad(5)

'Verifies if the object has the specific attribute'
WebUI.verifyElementHasAttribute(findTestObject('Labels/PrimaryWaferDiameterValue'), 'ng-reflect-value', 20, FailureHandling.CONTINUE_ON_FAILURE)

'Gets the value of the attribute of the object'
String WaferFabPrimaryWaferDiameter = WebUI.getAttribute(findTestObject('Labels/PrimaryWaferDiameterValue'), 'ng-reflect-value')

'Prints the value of the attribute of the object'
print((' ' + WaferFabPrimaryWaferDiameter) + ' ')

'Highlights the attribute value'
CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Labels/WaferDiameterLabel'))

'Gets the value of the text attribute of the object'
String BumpPrimaryWaferDiameter = WebUI.getText(findTestObject('Labels/WaferDiameterLabel'))

'Prints the value of the attribute of the object'
print((' ' + BumpPrimaryWaferDiameter) + ' ')

'Verifies if Wafer Fab Primary Wafer Diameter is not passed to Bump Primary Wafer Diameter'
if (WebUI.verifyNotEqual(WaferFabPrimaryWaferDiameter, BumpPrimaryWaferDiameter)) {
    'Marks the verification point as passed'
    KeywordUtil.markPassed('Wafer Fab Primary Wafer Diameter Value is not passed to Bump Primary Wafer Diameter.')
} else {
    'Marks the verification point as failed'
    KeywordUtil.markFailed('Wafer Fab Primary Wafer Diameter Value is passed to Bump Primary Wafer Diameter.')
}

'Delays the next step in 2 seconds for page load.'
WebUI.delay(2)

