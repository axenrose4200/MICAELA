import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.util.KeywordUtil as KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import internal.GlobalVariable as GlobalVariable

WebUI.comment('Waits for 30 seconds for page load.')

WebUI.waitForPageLoad(30)

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanLRPTECH'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanLRPTECH'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanTTemperature'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanTTemperature'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanTPlatform'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanTPlatform'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanBSBumpType'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanBSBumpType'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanBBump'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanBBump'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPackageDes'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPackageDes'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPins'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPins'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPackageGrp'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPackageGrp'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanFTTemperature'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanFTTemperature'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanFTestPlatform'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanFTestPlatform'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPrimaryHandler'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanPrimaryHandler'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Highlights the span object.')

not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanSecondaryHandler'))

WebUI.comment('Verifies if span object.')

if (WebUI.waitForElementPresent(findTestObject('Default Values/Sourcing Plan/SpanAttributes/spanSecondaryHandler'), 30)) {
    KeywordUtil.markPassed('Object span accross the table.')
} else {
    KeywordUtil.markFailed('Object does not span accross the table.')
}

WebUI.comment('Delays next step for 5 seconds for page load.')

WebUI.delay(5)

