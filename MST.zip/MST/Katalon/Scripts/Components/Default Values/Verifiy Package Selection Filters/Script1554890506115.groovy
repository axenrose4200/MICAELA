import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'Waits for 30 seconds for page load.'
WebUI.waitForPageLoad(30, FailureHandling.STOP_ON_FAILURE)

'Highlights Max Die X label.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Labels/MaxDieXLabel'))

'Verifies if Max Die X label exists.'
WebUI.waitForElementPresent(findTestObject('Labels/MaxDieXLabel'), 30)

'Highlights Max Die Y label.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Labels/MaxDieYLabel'))

'Verifies Max Die Y label exists.'
not_run: WebUI.waitForElementPresent(findTestObject('Labels/MaxDieYLabel'), 30)

'Highlights Leadframe Finish label.'
not_run: CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Labels/LeadframeFinishLabel'))

'Verifies Leadframe Finish label exists.'
not_run: WebUI.waitForElementPresent(findTestObject('Labels/LeadframeFinishLabel'), 30)

'Delays next step for 5 seconds for page load.'
WebUI.delay(5)

