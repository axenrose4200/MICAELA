import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.comment('Waits 30 seconds for page load.')

WebUI.waitForPageLoad(30)

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand1'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand1'), 30)){
	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand2'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand2'), 30)){
	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand3'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand3'), 30)){

	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand4'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand4'), 30)){
	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand5'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand5'), 30)){
	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Highlights the expand button.')

CustomKeywords.'com.reusableComponents.HighlightElement.run'(findTestObject('Default Values/Sourcing Plan/Expand/Expand6'))

WebUI.comment('Verifies if button is expanded.')

if (WebUI.verifyElementPresent(findTestObject('Default Values/Sourcing Plan/Expand/Expand6'), 30)){
	KeywordUtil.markPassed("Attribute is expanded.")
} else {
	KeywordUtil.markFailed("Attribute is not expanded.")
}

WebUI.comment('Delays next step for 5 seconds for page load.')

WebUI.delay(5)

