package com.reusableComponents

import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.testng.Assert

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.interactions.Actions

public class HighlightElement {
	static WebDriver driver = DriverFactory.getWebDriver()
	@Keyword
	public static void run(TestObject objectto) {
		try {
			WebElement element = WebUiCommonHelper.findWebElement(objectto, 20);
			for (int i = 0; i < 50; i++) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].setAttribute('style','background: gray;');",
						element);
				js.executeScript("arguments[0].setAttribute('style','background: clear;');",
						element);
			}
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	@Keyword
	public static CreateWebElement(String objProperty) {
		try {
			WebElement element = driver.findElement(By.xpath(objProperty))

			return element
		} catch (Exception e) {
			KeywordUtil.markFailed("Failed: Object with property: "+objProperty+" not found")
		}
	}


	@Keyword
	public static boolean ValidateObjectExist(String element) {

		List<WebElement> objects = driver.findElements(By.xpath(element))

		if (objects.size() > 0){
			return true
		}else{
			return false
		}
	}
	
	@Keyword
	def boolean isFileDownloaded(String downloadPath, String fileName) {
		boolean flag = false
		'Creating an object for File and passing the download Path as argument'
		File dir = new File(downloadPath)
		'Creating an Array where it will store all the files from that folder'
		File[] dir_contents = dir.listFiles()

		println('Total Files Available in the folder are : ' + dir_contents.length)
		'Iterating a loop for number of files available in the folder to verify file name in the folder'
		for (int i = 0; i < dir_contents.length; i++) {
			println('Downloaded Files : ' + dir_contents[i].getName())
			'Verifying the file name is available in the folder '
			if (dir_contents[i].getName().contains(fileName)) {
				'If the file is found then it will return a value as true'
				return flag = true
			}
		}
		'If the file is found then it will return a value as false'
		return flag
	}

	@Keyword
	def Hover(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver)
		action.moveToElement(element).build().perform()
	}
}
