import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\x0273571\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Test Cases\\Release_3\\Release_3.0_MST-44\\20200128_175408\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

not_run: WebUI.callTestCase(findTestCase('Components/Login/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Sourcing Selection Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/TabFilters/Fill Product Filters'), [('param_input1') : '1', ('param_input2') : '1'], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate to Wafer Fab Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/WaferFabFiltersMultipleValue/FillCTECHFilter'), [('param_value1') : ' LBC4 '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/WaferFabFiltersMultipleValue/FillLRPTECHFilter'), [('param_value1') : ' LBC4 '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/WaferFabFiltersMultipleValue/FillPrimaryFactoryFilter'), [('param_value1') : ' DL-LIN '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Probe Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/ProbeFilters/Fill Probe Test Temperature Filters'), [('param_value1') : ' Room '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/ProbeFilters/Fill Probe Tester Platform Filter'), [('param_value1') : ' ETS-364 '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/ProbeFilters/Fill Probe Primary Wafer Diameter Filter'), [('param_value1') : ' 150 '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/ProbeFilters/Fill Primary Factory Filter'), [('param_value1') : ' DL-LIN (ROADMAP) '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ClickProbeInsertion1CopyButton'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ClickProbeInsertion2Copy'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Backside Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/BacksideFilters/FillBacksideBumpTypeFilter'), [('param_value1') : ' AU '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToBumpTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/BumpFilters/FillBumpBumpTechFilter'), [('param_value1') : ' FLIP CHIP '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/BumpFilters/FillBumpBumpTypeFilter'), [('param_value1') : ' CUPILLAR '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToAssembly'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/AssemblyFilters/FillPackageDesignatorFilter'), [('param_value1') : 'AAB'], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate to Final Test Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/FinalTestFilters/FillFinalTestTemperature'), [('param_value1') : ' Room '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/FinalTestFilters/FillFinalTestPlatform'), [('param_value1') : ' ETS-364 '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/FinalTestFilters/FillFTPackageGroup'), [('param_value1') : ' BGA '], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ClickFinalTestInsertion1Copy'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ClickFinalTestInsertion2Copy'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToFilters'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/Click Reset All Filters Button'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Filters/TabFilters/Fill Product Filters'), [('param_input1') : '1', ('param_input2') : '1'], 
    FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate to Wafer Fab Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyWaferFabIsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToWaferFabTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Probe Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyProbeInsertion1IsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyProbeInsertionsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToProbeTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Backside Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyBacksideIsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToBacksideTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToBumpTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyBumpIsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToBumpTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToAssembly'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyAssembyIsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToAssembly'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate to Final Test Tab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandFactoryAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Buttons/ExpandTechnologyAttributes'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyFinalTestInsertion1Clear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/VerifyIfClear/VerifyFinalTestInsertionsClear'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Scroll/ScrollToFinalTestTab'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Logout/LogOutFinal'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.callTestCase(findTestCase('Components/Logout/Logout'), [:], FailureHandling.CONTINUE_ON_FAILURE)

''', 'Test Cases/Test Cases/Release_3/Release_3.0_MST-44', new TestCaseBinding('Test Cases/Test Cases/Release_3/Release_3.0_MST-44',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
