import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner
import com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner())


RunConfiguration.setExecutionSettingFile('C:\\Users\\x1056225\\AppData\\Local\\Temp\\Katalon\\Test Cases\\Test Cases\\Release_3\\Release_3.0_MST-199\\20200306_103821\\execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

'Log in to MST.'
not_run: WebUI.callTestCase(findTestCase('Components/Login/Login'), [:], FailureHandling.STOP_ON_FAILURE)

'Clicks the menu button.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/ClickHamburgerButton'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigate to Package Selection page.\\r\\n'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Package Selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigate to Saved Drafts Page.'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToSavedDrafts'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Delete heading'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Delete heading'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Search name instead of Draft Name heading'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Search name heading'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Revisions should be hidden for package search'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Revision should be hidden'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Created Date heading'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Created date heading'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Saved Date heading'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Saved date heading'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify Copy Link heading'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Copy link heading'), [:], FailureHandling.STOP_ON_FAILURE)

'Clicks on the menu.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/ClickHamburgerButton'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigate to Package Selection page.\\r\\n'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Package Selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify view saved searches on package selection columns: Search Name'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Search name.package selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify view saved searches on package selection columns: Saved'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Saved.package selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify view saved searches on package selection columns: Copy'
not_run: WebUI.callTestCase(findTestCase('Components/Default Values/Verify Copy.package selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Clicks on the menu.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/ClickHamburgerButton'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigate to Package Selection page.\\r\\n'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Package Selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify when a user is starting a new search (i.e. not opened from a previously saved search), the only save option is "Save As New"'
not_run: WebUI.callTestCase(findTestCase('Components/Verifications/Verify Save as option when starting'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigate to Save Drafts Page.'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/NavigateToSavedDrafts'), [:], FailureHandling.STOP_ON_FAILURE)

'Clicks on the menu.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/ClickHamburgerButton'), [:], FailureHandling.STOP_ON_FAILURE)

'Navigates to Package Selection page.'
not_run: WebUI.callTestCase(findTestCase('Components/Page Navigation/Navigate To Package Selection'), [:], FailureHandling.STOP_ON_FAILURE)

'Clicks the Draft Icon.\\r\\n'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/Click Draft Icon'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify When a user has modified a saved search for which the current user is the creator, the user will have the option to "Save" and "Save As New"'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/Verify Save and Save As New'), [:], FailureHandling.STOP_ON_FAILURE)

'Verify users should be able to email a shareable URL by clicking the "Share URL" button.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/Share URL Button'), [:], FailureHandling.STOP_ON_FAILURE)

'Package Search will share the same rules with respect to recipients of saved searches being unable to edit the original search, but may use Save As New to store the search to their saved searches.'
not_run: WebUI.callTestCase(findTestCase('Components/Buttons/Verify modified only Save As New Button Only'), [('paramSharedURL') : 'https://mstweb-staging.itg.ti.com/mst/packaging/wirebond?id=168'], 
    FailureHandling.STOP_ON_FAILURE)

'Package Search will share the same rules with respect to recipients of saved searches being unable to edit the original search, but may use Save As New to store the search to their saved searches.\\r\\nVerify When a user has modified a saved search for which the current user is not the creator, the only save option the user should have is "Save As New"'
WebUI.callTestCase(findTestCase('Components/Buttons/Re save others draft to own draft'), [('paramSharedURL') : 'https://mstweb-staging.itg.ti.com/mst/packaging/wirebond?id=168'], 
    FailureHandling.STOP_ON_FAILURE)

'Log out/Exit page.\\r\\n'
WebUI.callTestCase(findTestCase('Components/Logout/LogOutFinal'), [:], FailureHandling.STOP_ON_FAILURE)

'Closes the browser.'
WebUI.callTestCase(findTestCase('Components/Logout/CloseBrowser'), [:], FailureHandling.STOP_ON_FAILURE)

''', 'Test Cases/Test Cases/Release_3/Release_3.0_MST-199', new TestCaseBinding('Test Cases/Test Cases/Release_3/Release_3.0_MST-199',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
