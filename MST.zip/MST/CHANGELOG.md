# Changelog
All notable changes to this project will be documented in this file.

## 1.3.0
### Changed
* Converted Package Selection from Spotfire to **Java**
* Migrated to **Angular 8**
* Migrated to **Spring Boot 2**

### Added
* Standard **[ESIT CICD Pipeline](https://bitbucket.itg.ti.com/projects/ESIT-CICD/repos/esit-devops-pipelines/browse)** 
* **Dynamic environment variables** for Angular modules